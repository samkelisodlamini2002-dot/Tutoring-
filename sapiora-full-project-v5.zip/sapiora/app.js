const nav = document.getElementById("mainNav");
document.getElementById("menuToggle").addEventListener("click", () => nav.classList.toggle("open"));
document.getElementById("year").textContent = new Date().getFullYear();

function openModal(id, role) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.classList.add("open");
  modal.setAttribute("aria-hidden", "false");
  if (role && document.getElementById("joinRole")) {
    document.getElementById("joinRole").value = role;
    document.getElementById("joinRole").dispatchEvent(new Event("change"));
  }
}
function closeModal(modal) {
  modal.classList.remove("open");
  modal.setAttribute("aria-hidden", "true");
}
document.querySelectorAll("[data-modal]").forEach(button => {
  button.addEventListener("click", () => openModal(button.dataset.modal, button.dataset.role));
});
document.querySelectorAll("[data-close]").forEach(button => {
  button.addEventListener("click", () => closeModal(button.closest(".modal-backdrop")));
});
document.querySelectorAll(".modal-backdrop").forEach(backdrop => {
  backdrop.addEventListener("click", event => {
    if (event.target === backdrop) closeModal(backdrop);
  });
});
document.addEventListener("keydown", event => {
  if (event.key === "Escape") document.querySelectorAll(".modal-backdrop.open").forEach(closeModal);
});
const cfg = window.SAPIORA;
const sb = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
function say(el, msg, ok) { el.textContent = msg; el.style.color = ok ? "#2f6a3d" : "#8a2f2f"; }
function busy(form, on) { const b = form.querySelector("button[type=submit]"); b.disabled = on; b.style.opacity = on ? ".6" : ""; }
const nice = m => /Invalid login/i.test(m) ? "Email or password is incorrect." : /rate limit/i.test(m) ? "Too many attempts. Please wait a few minutes and try again." : m;

document.getElementById("joinForm").addEventListener("submit", async event => {
  event.preventDefault();
  const f = event.target, v = Object.fromEntries(new FormData(f)), q = readQuals(f), out = document.getElementById("joinFeedback");
  if (v.role === "teacher" && q.error) return say(out, q.error, false);
  busy(f, true); say(out, "Creating your account...", true);
  const { data, error } = await sb.auth.signUp({
    email: v.email.trim(), password: v.password,
    options: { data: { role: v.role, full_name: v.name.trim(), qualifications: v.role === "teacher" ? q.levels : [], programmes: v.role === "teacher" ? q.progs : [] }, emailRedirectTo: location.origin + "/platform.html#/account" }
  });
  busy(f, false);
  if (error) return say(out, nice(error.message), false);
  if (data.user && data.user.identities && data.user.identities.length === 0) return say(out, "An account with this email already exists. Please sign in instead.", false);
  if (data.session) { location.href = "platform.html#/account"; return; }
  f.reset(); say(out, "Account created. Check your email to confirm it, then sign in.", true);
});

document.getElementById("loginForm").addEventListener("submit", async event => {
  event.preventDefault();
  const f = event.target, v = Object.fromEntries(new FormData(f)), out = document.getElementById("loginFeedback");
  busy(f, true); say(out, "Signing in...", true);
  const { error } = await sb.auth.signInWithPassword({ email: v.email.trim(), password: v.password });
  busy(f, false);
  if (error) return say(out, nice(error.message), false);
  location.href = "platform.html#/account";
});

renderQualPicker(document.getElementById("qualList"));
document.getElementById("joinRole").addEventListener("change", e => { document.getElementById("qualBox").hidden = e.target.value !== "teacher"; });

document.getElementById("forgotBtn").addEventListener("click", async () => {
  const f = document.getElementById("loginForm"), out = document.getElementById("loginFeedback"), email = f.elements.email.value.trim();
  if (!email) return say(out, "Enter your email address above first.", false);
  const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + "/reset.html" });
  say(out, error ? nice(error.message) : "If that email has an account, a reset link is on its way.", !error);
});
