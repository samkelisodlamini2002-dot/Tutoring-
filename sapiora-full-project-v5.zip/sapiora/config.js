// Single place for settings. The publishable key is safe in the browser: RLS protects the data.
window.SAPIORA = {
  SUPABASE_URL: "https://ratgxathmuwyxobrsvij.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_APGyCETHUCJL5RAOrU7tqA_FzyBSDUX",
  LEVELS: [
    ["higher_certificate", "Higher Certificate in Education"],
    ["diploma", "Diploma in Education"],
    ["bed", "Bachelor of Education (BEd)"],
    ["pgce", "Bachelor's degree with PGCE"],
    ["ace", "Advanced Certificate in Education (ACE)"],
    ["advanced_diploma", "Advanced Diploma in Education"],
    ["honours", "Honours degree in Education"],
    ["masters", "Master's degree (MEd, MA or MSc)"],
    ["doctorate", "Doctorate (PhD or DEd)"],
    ["other", "Other teaching qualification"]
  ],
  PROGRAMMES: {
    higher_certificate: [["ecd", "Early Childhood Development (birth to Grade R)"], ["foundation", "Foundation Phase teaching (Grades R–3)"], ["tvet", "Technical and vocational teaching (TVET)"], ["adult", "Adult and community education"], ["other", "Other (add details below)"]],
    diploma: [["grade_r", "Grade R Teaching"], ["foundation", "Foundation Phase Teaching (Grades R–3)"], ["intermediate", "Intermediate Phase Teaching (Grades 4–6)"], ["senior_fet", "Senior Phase and FET Teaching (Grades 7–12)"], ["tvet", "Technical and Vocational Teaching"], ["ecd", "Early Childhood Development"], ["other", "Other (add details below)"]],
    bed: [["foundation", "Foundation Phase (Grades R–3)"], ["intermediate", "Intermediate Phase (Grades 4–6)"], ["senior_fet", "Senior Phase and FET (Grades 7–12)"], ["senior", "Senior Phase (Grades 7–9)"], ["fet", "FET Phase (Grades 10–12)"], ["ecd", "Early Childhood Development / Grade R"], ["tvet", "Technical and Vocational Education"], ["inclusive", "Inclusive and Special Needs Education"], ["other", "Other (add details below)"]],
    pgce: [["foundation", "Foundation Phase (Grades R–3)"], ["intermediate", "Intermediate Phase (Grades 4–6)"], ["senior_fet", "Senior Phase and FET (Grades 7–12)"], ["senior", "Senior Phase (Grades 7–9)"], ["fet", "FET Phase (Grades 10–12)"], ["tvet", "Post-school and vocational (TVET)"], ["other", "Other (add details below)"]],
    ace: [["maths", "Mathematics"], ["science", "Natural Sciences"], ["technology", "Technology"], ["languages", "Languages (English, Afrikaans or an African language)"], ["maths_lit", "Mathematical Literacy"], ["life_orientation", "Life Orientation"], ["leadership", "School Management and Leadership"], ["inclusive", "Inclusive and Special Needs Education"], ["ecd", "Early Childhood Development"], ["other", "Other (add details below)"]],
    advanced_diploma: [["leadership", "School Management and Leadership"], ["inclusive", "Inclusive Education"], ["maths", "Mathematics Teaching"], ["science", "Science Teaching"], ["languages", "Language Teaching"], ["technology", "Technology Education"], ["ecd", "Early Childhood Development"], ["other", "Other (add details below)"]],
    honours: [["curriculum", "Curriculum Studies"], ["leadership", "Educational Leadership, Management and Policy"], ["psychology", "Educational Psychology"], ["inclusive", "Inclusive and Special Needs Education"], ["maths", "Mathematics Education"], ["science", "Science Education"], ["languages", "Language Education"], ["ecd", "Early Childhood Development"], ["higher_ed", "Higher Education Studies"], ["edtech", "Educational Technology (ICT in Education)"], ["adult", "Adult and Community Education"], ["guidance", "Guidance and Counselling"], ["other", "Other (add details below)"]],
    masters: [["med_curriculum", "MEd Curriculum Studies"], ["med_leadership", "MEd Educational Leadership, Management and Policy"], ["med_psychology", "MEd Educational Psychology"], ["med_inclusive", "MEd Inclusive and Special Needs Education"], ["med_maths", "MEd Mathematics Education"], ["med_science", "MEd Science Education"], ["med_languages", "MEd Language Education"], ["med_ecd", "MEd Early Childhood Development"], ["med_higher_ed", "MEd Higher Education Studies"], ["med_edtech", "MEd Educational Technology"], ["med_adult", "MEd Adult and Community Education"], ["med_assessment", "MEd Assessment and Quality Assurance"], ["med_teacher_ed", "MEd Teacher Education"], ["med_general", "MEd (general or by research)"], ["ma_education", "MA in Education"], ["msc_education", "MSc in Mathematics or Science Education"], ["subject_masters", "Master's in a school subject area (e.g. Mathematics, English)"], ["other", "Other (add details below)"]],
    doctorate: [["phd_education", "PhD in Education"], ["ded", "Doctor of Education (DEd)"], ["phd_curriculum", "PhD Curriculum Studies"], ["phd_leadership", "PhD Educational Leadership, Management and Policy"], ["phd_psychology", "PhD Educational Psychology"], ["phd_inclusive", "PhD Inclusive and Special Needs Education"], ["phd_maths", "PhD Mathematics Education"], ["phd_science", "PhD Science Education"], ["phd_languages", "PhD Language Education"], ["phd_ecd", "PhD Early Childhood Development"], ["phd_higher_ed", "PhD Higher Education Studies"], ["phd_edtech", "PhD Educational Technology"], ["phd_teacher_ed", "PhD Teacher Education"], ["phd_subject", "PhD in a school subject area (e.g. Mathematics, Physics, English)"], ["other", "Other (add details below)"]],
    other: []
  },
  TERMS_VERSION: "2026-11-draft",
  // Staff portal addresses (set after you deploy them). Staff are pointed here from the public site.
  ADMIN_URL: "https://admin.samkeliso-dlamini2002.workers.dev",
  VERIFY_URL: "https://verify.samkeliso-dlamini2002.workers.dev",
  BANK: { holder: "SAPIORA (Pty) Ltd", bank: "Your bank", account: "0000000000", branch: "000000", type: "Business cheque" }
};
