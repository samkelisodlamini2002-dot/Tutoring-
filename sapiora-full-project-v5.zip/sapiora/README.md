# SAPIORA Education Network

A standalone project, separate from VIRELORA. SAPIORA is a professional education network concept for families, schools and qualified teachers.

## Design and scope
- Professional corporate visual theme with navy, white, slate and restrained antique-gold accents
- No games, game mechanics, quizzes, points, badges, leaderboards or entertainment sections
- Responsive landing page for families, schools and qualified educators
- Teacher qualification and professional-registration review explanation
- Demo enquiry and sign-in modals
- Initial Supabase schema for user profiles, teacher applications, private document metadata and enquiries
- Cloudflare Pages-ready static files and security headers

## Run locally
Open `index.html` in a browser, or run a local static server from this directory:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy using Cloudflare Pages
This project is a static website and can be deployed directly to **Cloudflare Pages**.

### Git-connected deployment
1. Create a new Git repository for SAPIORA. Keep it separate from the VIRELORA repository.
2. Push the contents of this project folder to that repository.
3. In the Cloudflare dashboard, open **Workers & Pages** and create a Pages project connected to the new repository.
4. Choose the production branch (usually `main`).
5. For this plain HTML/CSS/JavaScript project, leave the build command empty.
6. Set the build output directory to `/` (the repository root).
7. Deploy. Cloudflare Pages will serve `index.html` and apply the rules in `_headers`.
8. Add a custom domain in the Pages project when ready.

### Direct upload
You can also create a Pages project using Direct Upload and upload the extracted project folder. For ongoing development, Git integration is recommended.

No Netlify configuration is included.

## Supabase setup
1. Create a separate Supabase project for SAPIORA.
2. Review `supabase/schema.sql` before running it.
3. Configure Supabase Auth and email confirmation.
4. Create a **private** Storage bucket for qualification evidence.
5. Implement and test row-level security policies before exposing any real user data.
6. Implement admin review actions using trusted server-side functions. Never trust a browser-side `role=admin` value.
7. Publish teacher profiles only after an administrator has approved the related application.
8. Add an audit trail and document-retention rules.

## Prototype limitations
This is a front-end starter, not a live marketplace. Forms display local demo messages and do not save or transmit information. Authentication, teacher search, document upload, admin dashboard, booking, payment collection and teacher payouts are not connected.

SAPIORA is not affiliated with SACE and does not itself confer professional registration or accreditation. Any SACE status checks must use authorised channels and appropriate consent. Do not request or store sensitive documents until access controls, privacy notices, retention periods and security measures have been implemented.

## Suggested next milestones
1. Supabase authentication and role-based onboarding
2. Private teacher application and secure document upload
3. Admin review dashboard and approval audit trail
4. Public directory showing approved teachers only
5. Parent/guardian and school enquiry dashboards
6. Lesson booking, cancellation and safeguarding workflows
7. Payment provider integration after the commercial and compliance model is defined

## Platform setup (new)
1. In Supabase SQL editor run, in order: `schema.sql`, `002_platform_core.sql`, `003_eft_payments.sql`.
2. Edit the top of `platform.js`: set `SUPABASE_URL`, `SUPABASE_ANON_KEY` and your real `BANK` details.
3. Sign up, then promote your first admin: `update public.profiles set role='admin' where email='you@example.com';`
4. Deploy to Cloudflare Pages as before. Teachers appear in the directory only after an admin approves them.
EFT flow: parent pays and uploads proof, admin confirms, lesson completed, admin creates and pays the teacher payout.
