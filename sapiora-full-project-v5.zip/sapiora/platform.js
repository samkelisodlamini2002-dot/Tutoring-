// ===== Configuration lives in config.js =====
const { SUPABASE_URL, SUPABASE_ANON_KEY, BANK, LEVELS, TERMS_VERSION } = window.SAPIORA;
const levelLabel = c => (LEVELS.find(l => l[0] === c) || [c, c])[1];
let meMeta = {};
let isVerifier = false;
const PHASES = ["Foundation Phase (Grades R–3)", "Intermediate Phase (Grades 4–6)", "Senior Phase (Grades 7–9)", "FET Phase (Grades 10–12)"];
const JOB_TYPES = { tutoring: "Tutoring", part_time: "Part-time", full_time: "Full-time", holiday_class: "Holiday classes", contract: "Contract" };
const FORMATS = { online: "Online", in_person: "In person", either: "Online or in person" };
const ago = d => { const n = Math.floor((Date.now() - new Date(d)) / 864e5); return n < 1 ? "Today" : n === 1 ? "Yesterday" : n + " days ago"; };
const opts = (o, first) => `<option value="">${first}</option>` + Object.entries(o).map(([k, v]) => `<option value="${k}">${esc(v)}</option>`).join("");

const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const app = document.getElementById("app");
let me = null; // profile
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const rand = c => "R" + (c / 100).toLocaleString("en-ZA", { minimumFractionDigits: 2 });
const when = d => new Date(d).toLocaleString("en-ZA", { dateStyle: "medium", timeStyle: "short" });
const list = s => String(s || "").split(",").map(x => x.trim()).filter(Boolean);
const tag = (t, c = "") => `<span class="tag ${c}">${esc(t)}</span>`;
const statusClass = s => ({ approved: "ok", accepted: "ok", paid: "ok", completed: "ok", rejected: "bad", declined: "bad", cancelled: "bad", failed: "bad", open: "ok", shortlisted: "ok", pending_review: "warn", submitted: "warn", closed: "bad", withdrawn: "bad", awaiting_payment: "warn", needs_information: "warn", pending: "warn", requested: "warn" }[s] || "");
const label = s => String(s).replace(/_/g, " ");
const fail = e => { const el = document.activeElement?.closest?.("form")?.querySelector(".err") || document.querySelector(".err"); const m = e?.message || String(e); if (el) el.textContent = m; else alert(m); };
async function run(fn) { try { await fn(); } catch (e) { fail(e); } }
const must = r => { if (r.error) throw r.error; return r.data; };
const signed = async (bucket, path) => (await sb.storage.from(bucket).createSignedUrl(path, 300)).data?.signedUrl;

// ===== Session & profile =====
async function loadMe() {
  const { data: { session } } = await sb.auth.getSession();
  me = null; meMeta = {}; isVerifier = false;
  if (session) {
    let p = must(await sb.from("profiles").select("*").eq("id", session.user.id).maybeSingle());
    const m = session.user.user_metadata || {}; meMeta = m;
    if (!p && ["teacher", "parent", "school"].includes(m.role)) {
      p = must(await sb.from("profiles").insert({ id: session.user.id, role: m.role, full_name: m.full_name || "Member", email: session.user.email }).select().single());
    }
    me = p;
    if (me) isVerifier = !!must(await sb.from("verifiers").select("user_id").eq("user_id", me.id).maybeSingle());
  }
  document.getElementById("navAuth").innerHTML = me
    ? `<a href="#/account">My account</a> <button class="btn btn-outline btn-small" data-act="signout">Sign out</button>`
    : `<a href="#/login">Sign in</a>`;
}

// ===== Router =====
async function route() {
  const [, path = "", arg] = location.hash.slice(1).split("/");
  await run(async () => {
    await loadMe();
    if (path === "login") return viewAuth();
    if (path === "account") return me ? viewAccount() : (location.hash = "#/login");
    if (path === "jobs") return arg ? viewJob(arg) : viewJobs();
    if (path === "book" && arg) return me ? viewBookForm(arg) : (location.hash = "#/login");
    return viewDirectory();
  });
}
addEventListener("hashchange", route); route();

// ===== Verification levels (only what the team has actually checked) =====
const CHECKS = [["identity", "Identity"], ["qualification", "Qualification"], ["sace", "SACE registration"], ["police_clearance", "Police clearance"]];
const todayISO = () => new Date().toISOString().slice(0, 10);
const checkLive = c => !!c && (!c.expires_on || c.expires_on >= todayISO());
const groupChecks = rows => (rows || []).reduce((m, c) => { (m[c.teacher_id] = m[c.teacher_id] || {})[c.check_type] = c; return m; }, {});
const tierOf = ck => { const ok = k => checkLive(ck && ck[k]); return ok("identity") && ok("qualification") ? (ok("sace") && ok("police_clearance") ? "full" : "core") : "basic"; };
const TIER = { full: ["Fully vetted", "ok"], core: ["ID and qualification verified", "ok"], basic: ["Approved", ""] };
const monthYear = d => new Date(d).toLocaleDateString("en-ZA", { month: "short", year: "numeric" });
const checkChips = ck => CHECKS.filter(([k]) => checkLive(ck && ck[k])).map(([k, l]) => `<span class="chip">✓ ${esc(l)}${ck[k].expires_on ? " (valid to " + monthYear(ck[k].expires_on) + ")" : ""}</span>`).join("");
const loadChecks = async teacherId => { // never breaks a page if the checks table is not installed yet
  let q = sb.from("teacher_checks").select("teacher_id,check_type,verified_at,expires_on"); if (teacherId) q = q.eq("teacher_id", teacherId);
  const r = await q; return groupChecks(r.error ? [] : r.data);
};
const VERIF_EXPLAINER = `<details class="card"><summary><b>How SAPIORA verifies teachers</b></summary>
  <p class="muted">Every listed teacher has been reviewed and approved by our verification team. Badges show exactly which checks were completed, and a badge only appears once the team has seen the evidence.</p>
  <p><span class="chip">✓ Identity</span> ID document checked against the teacher's name.<br><span class="chip">✓ Qualification</span> Teaching qualification confirmed as genuine.<br><span class="chip">✓ SACE registration</span> Registration with the South African Council for Educators confirmed.<br><span class="chip">✓ Police clearance</span> Clearance certificate seen and still in date. It disappears when it expires.</p>
  <p class="muted"><b>Fully vetted</b> means all four checks are current. Documents are seen only by the verification team and are never shown publicly.</p></details>`;

// ===== Public directory (approved teachers only; enforced by RLS) =====
async function viewDirectory() {
  const rows = must(await sb.from("teacher_public_profiles").select("*").eq("published", true).order("display_name"));
  const cks = await loadChecks();
  app.innerHTML = `<h1>Approved teachers</h1><p class="lede">Every teacher listed here has had their qualifications reviewed and approved by SAPIORA.</p>${VERIF_EXPLAINER}
  <form class="card" data-form="filter"><div class="grid2"><label>Subject or grade<input name="q" placeholder="e.g. Mathematics, Grade 10"></label><label>Highest qualification held<select name="level"><option value="">Any qualification</option>${LEVELS.map(([c, l]) => `<option value="${c}">${esc(l)}</option>`).join("")}</select></label><label>Format<select name="fmt"><option value="">Any format</option><option value="online">Online</option><option value="in person">In person</option></select></label><label>Verification<select name="ver"><option value="">Any level</option><option value="core">ID and qualification verified</option><option value="full">Fully vetted</option></select></label></div></form><div id="dir"></div>`;
  const draw = () => {
    const v = Object.fromEntries(new FormData(app.querySelector("form"))), q = v.q.toLowerCase();
    const f = rows.filter(r => (!q || [...r.subjects, ...r.grades].join(" ").toLowerCase().includes(q)) && (!v.level || (r.qualification_levels || []).includes(v.level)) && (!v.fmt || r.formats.join(" ").toLowerCase().includes(v.fmt)) && (!v.ver || tierOf(cks[r.teacher_id]) === "full" || (v.ver === "core" && tierOf(cks[r.teacher_id]) === "core")));
    document.getElementById("dir").innerHTML = f.length ? f.map(t => { const ck = cks[t.teacher_id], [tl, tc] = TIER[tierOf(ck)]; return `<article class="card"><div class="row"><h3>${esc(t.display_name)}</h3>${tag(tl, tc)}</div>
      ${checkChips(ck) ? `<p>${checkChips(ck)}</p>` : ""}<p>${esc(t.bio)}</p>${(t.qualification_levels || []).length ? `<p class="muted">Qualifications: ${esc(qualSummary(t.qualification_levels, t.qualification_programmes))}</p>` : ""}<small>${esc(t.subjects.join(", "))} · ${esc(t.grades.join(", "))} · ${esc(t.formats.join(", "))}</small>
      <div class="actions"><a class="btn btn-primary btn-small" href="#/book/${t.teacher_id}">Request a lesson</a></div></article>`; }).join("")
      : `<p class="muted">No approved teachers match yet. Check back soon.</p>`;
  };
  draw(); app.querySelector("form").addEventListener("input", draw);
}

// ===== Sign in / register =====
function viewAuth() {
  setTimeout(() => { const q = document.getElementById("qualList"); if (q) renderQualPicker(q); });
  app.innerHTML = `<h1>Sign in or create an account</h1><p class="lede">Teachers are listed only after an administrator approves their credentials.</p>
  <form class="card" data-form="signin"><h3>Sign in</h3><label>Email<input name="email" type="email" required autocomplete="email"></label>
  <label>Password<input name="password" type="password" required autocomplete="current-password"></label><button class="btn btn-primary">Sign in</button> <button type="button" class="link-btn" data-act="forgot">Forgot your password?</button><p class="err" role="alert"></p></form>
  <form class="card" data-form="signup"><h3>Create an account</h3>
  <label>I am a<select name="role" required><option value="parent">Parent or guardian</option><option value="school">School representative</option><option value="teacher">Qualified teacher</option></select></label>
  <fieldset class="qual" id="qualBox" hidden><legend>Teaching qualifications you hold (tick all that apply)</legend><div id="qualList"></div></fieldset>
  <label>Full name<input name="name" required autocomplete="name"></label><label>Email<input name="email" type="email" required autocomplete="email"></label>
  <label>Password (8+ characters)<input name="password" type="password" minlength="8" required autocomplete="new-password"></label>
  <button class="btn btn-primary">Create account</button><p class="err" role="alert"></p></form>`;
}

// ===== Staff accounts are sent to their own portals =====
function staffNotice() {
  const { ADMIN_URL, VERIFY_URL } = window.SAPIORA;
  const links = [me.role === "admin" && ADMIN_URL ? `<a href="${esc(ADMIN_URL)}"><u>Admin portal</u></a>` : "", isVerifier && VERIFY_URL ? `<a href="${esc(VERIFY_URL)}"><u>Verification portal</u></a>` : ""].filter(Boolean).join(" · ");
  return `<div class="notice">Admin and verification work is done in the separate staff portals, not on this site.${links ? " Open: " + links : ""}</div>`;
}

// ===== Account router by role =====
async function viewAccount() {
  if (!me) return;
  app.innerHTML = `<h1>Welcome, ${esc(me.full_name)}</h1><p class="lede">${esc(me.role)} account</p><div id="acct"></div><p class="err" role="alert"></p>`;
  const box = document.getElementById("acct");
  const staffNote = me.role === "admin" || isVerifier ? staffNotice() : "";
  if (me.role === "teacher") box.innerHTML = staffNote + await teacherHTML() + await teacherJobsHTML();
  else if (me.role === "admin" || isVerifier) box.innerHTML = staffNote;
  else box.innerHTML = await requesterHTML() + await postsHTML();
  const qp = document.getElementById("qualPick");
  if (qp) renderQualPicker(qp, JSON.parse(qp.dataset.levels), JSON.parse(qp.dataset.progs));
}

// ===== Teacher =====
async function teacherHTML() {
  const a = must(await sb.from("teacher_applications").select("*, teacher_documents(*)").eq("user_id", me.id).maybeSingle());
  const locked = a && !["draft", "needs_information"].includes(a.review_status);
  const myCk = a ? (await loadChecks(me.id))[me.id] || {} : {};
  let h = `<h2>Professional application</h2>`;
  if (a) h += `<div class="card row"><span>Status: ${tag(label(a.review_status), statusClass(a.review_status))}</span>${a.review_status === "approved" ? "<small>You are listed in the public directory.</small>" : ""}</div>
    ${a.review_status === "needs_information" ? `<div class="notice">The reviewer needs more information: ${esc(a.reviewer_notes)} Add what was requested below, then submit for review again.</div>` : ""}
    ${a.review_status === "rejected" ? `<div class="notice">Application declined: ${esc(a.reviewer_notes)}</div>` : ""}`;
  if (a && a.review_status === "approved") {
    const [tl, tc] = TIER[tierOf(myCk)];
    h += `<div class="card"><div class="row"><h3>Your verification</h3>${tag(tl, tc)}</div><small>These badges are shown to parents and schools. A badge appears once the verification team has seen your evidence.</small>
    ${CHECKS.map(([k, l]) => { const c = myCk[k]; return `<div class="checkrow"><span>${esc(l)}</span><span>${!c ? '<span class="muted">Not verified yet</span>' : checkLive(c) ? tag("Verified" + (c.expires_on ? " until " + monthYear(c.expires_on) : ""), "ok") : tag("Expired. Upload a new one", "warn")}</span></div>`; }).join("")}
    ${checkLive(myCk.police_clearance) ? "" : `<p class="muted">Upload a police clearance certificate below to earn the Fully vetted level.</p>`}</div>`;
  }
  h += `<form class="card" data-form="application"><fieldset ${locked ? "disabled" : ""} style="border:0;padding:0;margin:0">
    <label>Professional bio<textarea name="bio" rows="4" required>${esc(a?.professional_bio)}</textarea></label>
    <div class="grid2"><label>Subjects (comma separated)<input name="subjects" value="${esc(a?.subjects?.join(", "))}" required></label>
    <label>Grades (comma separated)<input name="grades" value="${esc(a?.grades?.join(", "))}" required></label>
    <label>Formats (online, in person)<input name="formats" value="${esc(a?.teaching_formats?.join(", "))}" required></label>
    <label>Hourly rate (Rand)<input name="rate" type="number" min="1" step="1" value="${a?.hourly_rate_cents ? a.hourly_rate_cents / 100 : ""}"></label>
    <label>SACE registration number<input name="sace" value="${esc(a?.sace_number)}"></label></div>
    <fieldset class="qual"><legend>Teaching qualifications you hold (tick all that apply)</legend><div id="qualPick" data-levels="${esc(JSON.stringify(a?.qualification_levels?.length ? a.qualification_levels : (meMeta.qualifications || [])))}" data-progs="${esc(JSON.stringify(a?.qualification_levels?.length ? (a.qualification_programmes || []) : (meMeta.programmes || [])))}"></div></fieldset>
    <label>Qualification details (institution, year, subjects)<textarea name="qual" rows="3" required>${esc(a?.qualification_summary)}</textarea></label>
    <button class="btn btn-outline">Save draft</button></fieldset></form>`;
  if (a) {
    h += `<h2>Documents</h2><p class="muted">Upload identity and qualification documents (a police clearance certificate is optional, and earns a higher verification level). They are private and visible only to you and SAPIORA reviewers.</p>`;
    h += (a.teacher_documents || []).map(d => `<div class="card row"><span>${esc(d.document_type)} · ${esc(d.storage_path.split("/").pop())}</span>${locked ? "" : `<button class="btn btn-danger btn-small" data-act="deldoc" data-id="${d.id}" data-path="${esc(d.storage_path)}">Remove</button>`}</div>`).join("");
    if (a.review_status === "approved") h += `<form class="card" data-form="doc" data-app="${a.id}"><div class="grid2"><label>Add a document<select name="type"><option value="police_clearance">Police clearance certificate</option></select></label>
      <label>File (PDF or image)<input name="file" type="file" accept=".pdf,image/*" required></label></div><button class="btn btn-outline">Upload</button></form>`;
    if (!locked) h += `<form class="card" data-form="doc" data-app="${a.id}"><div class="grid2"><label>Type<select name="type"><option value="identity">Identity</option><option value="qualification">Teaching qualification</option><option value="sace_evidence">SACE evidence</option><option value="police_clearance">Police clearance certificate</option><option value="other">Other</option></select></label>
      <label>File (PDF or image)<input name="file" type="file" accept=".pdf,image/*" required></label></div><button class="btn btn-outline">Upload</button></form>
      <div class="card"><label style="display:flex;gap:10px;align-items:flex-start;margin:0"><input type="checkbox" id="termsBox" style="width:auto;margin-top:3px" ${a.terms_version ? "checked" : ""}> <span>I have read and accept the <a href="terms.html" target="_blank" rel="noopener"><u>Teacher Services Agreement</u></a>, including the rule that paid lessons with clients I meet through SAPIORA go through the platform.</span></label></div><div class="actions"><button class="btn btn-primary" data-act="submitapp" data-id="${a.id}">Submit for review</button></div>`;
  }
  const bk = must(await sb.from("bookings").select("*").eq("teacher_id", me.id).order("starts_at"));
  const paidIds = new Set(must(await sb.from("payments").select("booking_id").eq("status", "paid").in("booking_id", [...bk.map(b => b.id), "00000000-0000-0000-0000-000000000000"])).map(r => r.booking_id));
  const contacts = {}; await Promise.all([...paidIds].map(async id => { contacts[id] = (await sb.rpc("get_booking_contact", { p_booking: id })).data; }));
  const po = must(await sb.from("payouts").select("*").eq("teacher_id", me.id).order("created_at", { ascending: false }));
  h += `<h2>Lesson requests</h2>` + (bk.map(b => `<div class="card"><div class="row"><h3>${esc(b.subject)} · ${esc(b.requester_name)}</h3>${tag(b.status, statusClass(b.status))}</div>
    <small>${when(b.starts_at)} – ${when(b.ends_at)} · ${esc(b.learner_grade)} · ${esc(b.learning_format)}</small><p>${esc(b.message)}</p>
    <p class="muted">${contacts[b.id] ? "Family contact: " + esc(contacts[b.id]) : "Contact details are shared once the family has paid through SAPIORA."}</p>
    ${b.status === "accepted" && !paidIds.has(b.id) ? '<div class="notice">Waiting for the family to pay. Please do not teach before payment is confirmed.</div>' : ""}
    <div class="actions">${b.status === "requested" ? `<button class="btn btn-primary btn-small" data-act="accept" data-id="${b.id}">Accept & set price</button><button class="btn btn-danger btn-small" data-act="decline" data-id="${b.id}">Decline</button>` : ""}
    ${b.status === "accepted" && new Date(b.ends_at) < new Date() && paidIds.has(b.id) ? `<button class="btn btn-primary btn-small" data-act="complete" data-id="${b.id}">Mark completed</button>` : ""}
    ${["requested", "accepted"].includes(b.status) ? `<button class="btn btn-outline btn-small" data-act="cancel" data-id="${b.id}">Cancel</button>` : ""}<button class="btn btn-outline btn-small" data-act="msgs" data-id="${b.id}">Messages</button></div><div class="thread" id="thread-${b.id}" hidden></div></div>`).join("") || `<p class="muted">No requests yet.</p>`);
  h += `<h2>Payouts</h2>` + (po.map(p => `<div class="card row"><span>${rand(p.amount_cents)}</span>${tag(p.status, statusClass(p.status))}<small>${when(p.created_at)}</small></div>`).join("") || `<p class="muted">No payouts yet. Payouts are made by EFT after lessons are completed and the family's payment is confirmed.</p>`);
  return h;
}

// ===== Parent / school =====
async function requesterHTML() {
  const [bk, pay, dir] = await Promise.all([
    sb.from("bookings").select("*").eq("requester_id", me.id).order("starts_at"),
    sb.from("payments").select("*").eq("payer_id", me.id),
    sb.from("teacher_public_profiles").select("teacher_id,display_name")]).then(r => r.map(must));
  const names = Object.fromEntries(dir.map(d => [d.teacher_id, d.display_name]));
  const pbk = Object.fromEntries(pay.filter(p => p.status !== "failed").map(p => [p.booking_id, p]));
  return `<p><a class="btn btn-primary btn-small" href="#/">Find a teacher</a></p><h2>Your lessons</h2>` + (bk.map(b => {
    const p = pbk[b.id];
    return `<div class="card"><div class="row"><h3>${esc(b.subject)} with ${esc(names[b.teacher_id] || "teacher")}</h3>${tag(b.status, statusClass(b.status))}</div>
    <small>${when(b.starts_at)} – ${when(b.ends_at)}${b.price_cents ? " · " + rand(b.price_cents) : ""}</small>
    ${b.status === "accepted" && !p ? `<div class="actions"><button class="btn btn-primary btn-small" data-act="pay" data-id="${b.id}">Pay by EFT</button></div>` : ""}
    ${p ? `<div class="bank">Payment ${tag(p.status, statusClass(p.status))}<br>${p.status === "pending" ? `Pay ${rand(p.amount_cents)} to ${esc(BANK.holder)}, ${esc(BANK.bank)}, account ${esc(BANK.account)}, branch ${esc(BANK.branch)} (${esc(BANK.type)}).<br><b>Use reference: ${esc(p.provider_ref)}</b>
      ${p.proof_path ? "<br>Proof uploaded. Awaiting confirmation." : `<form data-form="proof" data-id="${p.id}"><label>Upload proof of payment<input name="file" type="file" accept=".pdf,image/*" required></label><button class="btn btn-outline btn-small">Upload proof</button></form>`}` : "Thank you. Payment confirmed."}</div>` : ""}
    ${["requested", "accepted"].includes(b.status) ? `<div class="actions"><button class="btn btn-outline btn-small" data-act="cancel" data-id="${b.id}">Cancel lesson</button></div>` : ""}<div class="actions"><button class="btn btn-outline btn-small" data-act="msgs" data-id="${b.id}">Messages</button></div><div class="thread" id="thread-${b.id}" hidden></div></div>`;
  }).join("") || `<p class="muted">No lesson requests yet.</p>`);
}

async function viewBookForm(tid) {
  if (!["parent", "school"].includes(me.role)) { app.innerHTML = `<h1>Lesson requests</h1><p class="lede">Only parent and school accounts can request lessons.</p>`; return; }
  const t = must(await sb.from("teacher_public_profiles").select("*").eq("teacher_id", tid).maybeSingle());
  if (!t) { app.innerHTML = `<h1>Teacher not available</h1><p class="lede">This teacher is not listed.</p>`; return; }
  const bck = (await loadChecks(tid))[tid], [btl, btc] = TIER[tierOf(bck)];
  app.innerHTML = `<h1>Request a lesson with ${esc(t.display_name)}</h1><p>${tag(btl, btc)} ${checkChips(bck)}</p><p class="lede">The teacher will accept and confirm a price before you pay.</p>
  <form class="card" data-form="book" data-teacher="${tid}"><div class="grid2"><label>Subject<select name="subject">${t.subjects.map(s => `<option>${esc(s)}</option>`).join("")}</select></label>
  <label>Learner grade<input name="grade" required></label><label>Start<input name="start" type="datetime-local" required></label><label>End<input name="end" type="datetime-local" required></label>
  <label>Format<select name="format">${t.formats.map(s => `<option>${esc(s)}</option>`).join("")}</select></label></div>
  <label>Message to the teacher<textarea name="msg" rows="3"></textarea></label><button class="btn btn-primary">Send request</button><p class="err" role="alert"></p></form>`;
}

// ===== Actions =====
const refresh = () => (location.hash === "#/account" ? viewAccount() : (location.hash = "#/account"));
const setBooking = (id, patch) => run(async () => { must(await sb.from("bookings").update(patch).eq("id", id)); refresh(); });
document.addEventListener("click", e => {
  const b = e.target.closest("[data-act]"); if (!b) return;
  const { act, id } = b.dataset;
  run(async () => {
    if (act === "signout") { await sb.auth.signOut(); location.hash = "#/"; }
    else if (act === "forgot") {
      const f = b.closest("form"), el = f.querySelector(".err"), email = f.elements.email.value.trim();
      if (!email) { el.style.color = "#8a2f2f"; el.textContent = "Enter your email above first."; return; }
      must(await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + "/reset.html" }));
      el.style.color = "#2f6a3d"; el.textContent = "If that email has an account, a reset link is on its way.";
    }
    else if (act === "msgs") { const box = document.getElementById("thread-" + id); if (!box.hidden) { box.hidden = true; return; } box.hidden = false; await loadThread(id); }
    else if (act === "save") {
      const on = b.dataset.on === "1";
      if (on) must(await sb.from("saved_jobs").delete().eq("teacher_id", me.id).eq("job_id", id));
      else must(await sb.from("saved_jobs").insert({ teacher_id: me.id, job_id: id }));
      b.dataset.on = on ? "0" : "1"; b.textContent = on ? "Save" : "Saved";
    }
    else if (act === "withdraw") { if (confirm("Withdraw this application?")) { must(await sb.from("job_applications").update({ status: "withdrawn" }).eq("id", id)); refresh(); } }
    else if (act === "closejob") { if (confirm("Close this opportunity?")) { must(await sb.from("job_posts").update({ status: "closed" }).eq("id", id)); refresh(); } }
    else if (act === "appstatus") { must(await sb.from("job_applications").update({ status: b.dataset.s }).eq("id", id)); refresh(); }
    else if (act === "submitapp") {
      if (!document.getElementById("termsBox")?.checked) throw new Error("Please read and accept the Teacher Services Agreement first.");
      must(await sb.from("teacher_applications").update({ terms_version: TERMS_VERSION, review_status: "submitted" }).eq("id", id)); refresh();
    }
    else if (act === "deldoc") { await sb.storage.from("credentials").remove([b.dataset.path]); must(await sb.from("teacher_documents").delete().eq("id", id)); refresh(); }
    else if (act === "accept") { const r = parseFloat(prompt("Price for this lesson (Rand):")); if (r > 0) setBooking(id, { status: "accepted", price_cents: Math.round(r * 100) }); }
    else if (act === "decline") setBooking(id, { status: "declined" });
    else if (act === "complete") setBooking(id, { status: "completed" });
    else if (act === "cancel") { if (confirm("Cancel this lesson?")) setBooking(id, { status: "cancelled" }); }
    else if (act === "pay") { must(await sb.rpc("create_eft_payment", { p_booking: id })); refresh(); }
  });
});

document.addEventListener("submit", e => {
  const f = e.target, k = f.dataset.form; if (!k) return;
  e.preventDefault(); const v = Object.fromEntries(new FormData(f));
  run(async () => {
    if (k === "signin") { must(await sb.auth.signInWithPassword(v)); location.hash = "#/account"; }
    else if (k === "signup") {
      const q = readQuals(f);
      if (v.role === "teacher" && q.error) throw new Error(q.error);
      const r = must(await sb.auth.signUp({ email: v.email, password: v.password, options: { data: { role: v.role, full_name: v.name, qualifications: v.role === "teacher" ? q.levels : [], programmes: v.role === "teacher" ? q.progs : [] }, emailRedirectTo: location.origin + "/platform.html#/account" } }));
      if (!r.session) { f.querySelector(".err").style.color = "#2f6a3d"; f.querySelector(".err").textContent = "Check your email to confirm your account, then sign in."; }
      else location.hash = "#/account";
    }
    else if (k === "application") {
      const q = readQuals(f);
      if (q.error) throw new Error(q.error);
      const row = { user_id: me.id, qualification_levels: q.levels, qualification_programmes: q.progs, professional_bio: v.bio, subjects: list(v.subjects), grades: list(v.grades), teaching_formats: list(v.formats),
        qualification_summary: v.qual, sace_number: v.sace || null, hourly_rate_cents: v.rate ? Math.round(v.rate * 100) : null };
      must(await sb.from("teacher_applications").upsert(row, { onConflict: "user_id" })); refresh();
    }
    else if (k === "doc") {
      const file = v.file; if (file.size > 10e6) throw new Error("File must be under 10 MB.");
      const path = `${me.id}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
      must(await sb.storage.from("credentials").upload(path, file));
      must(await sb.from("teacher_documents").insert({ application_id: f.dataset.app, document_type: v.type, storage_path: path })); refresh();
    }
    else if (k === "proof") {
      const file = v.file; if (file.size > 10e6) throw new Error("File must be under 10 MB.");
      const path = `${me.id}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
      must(await sb.storage.from("eft-proofs").upload(path, file));
      must(await sb.rpc("attach_eft_proof", { p_payment: f.dataset.id, p_path: path })); refresh();
    }
    else if (k === "msg") { must(await sb.from("booking_messages").insert({ booking_id: f.dataset.id, sender_id: me.id, body: v.body.trim() })); await loadThread(f.dataset.id); }
    else if (k === "feeproof") {
      const file = v.file; if (file.size > 10e6) throw new Error("File must be under 10 MB.");
      const path = `${me.id}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
      must(await sb.storage.from("eft-proofs").upload(path, file));
      must(await sb.from("job_posts").update({ fee_proof_path: path }).eq("id", f.dataset.id)); refresh();
    }
    else if (k === "apply") { must(await sb.from("job_applications").insert({ job_id: f.dataset.job, teacher_id: me.id, cover_note: v.note })); viewJob(f.dataset.job); }
    else if (k === "postjob") {
      must(await sb.from("job_posts").insert({ poster_id: me.id, organisation: v.org, title: v.title, description: v.desc, subjects: list(v.subjects),
        phases: new FormData(f).getAll("phases"), format: v.fmt, location: v.loc || null, job_type: v.type, pay_text: v.pay || null, closes_on: v.closes || null })); refresh();
    }
    else if (k === "book") {
      must(await sb.from("bookings").insert({ requester_id: me.id, teacher_id: f.dataset.teacher, subject: v.subject, learner_grade: v.grade,
        learning_format: v.format, message: v.msg, starts_at: new Date(v.start).toISOString(), ends_at: new Date(v.end).toISOString() }));
      location.hash = "#/account";
    }
  });
});

document.addEventListener("change", e => { if (e.target.name === "role") { const box = document.getElementById("qualBox"); if (box) box.hidden = e.target.value !== "teacher"; } });

// ===== Opportunities (Indeed-style board) =====
const jobMeta = j => `${esc(j.organisation)} · ${esc(j.location || "Location flexible")} · ${FORMATS[j.format]} · ${JOB_TYPES[j.job_type]}`;
const jobTags = j => [...j.subjects, ...j.phases].map(t => tag(t)).join(" ");

async function viewJobs() {
  const jobs = must(await sb.from("job_posts").select("*").eq("status", "open").order("created_at", { ascending: false }).limit(300));
  const saved = me?.role === "teacher" ? new Set(must(await sb.from("saved_jobs").select("job_id").eq("teacher_id", me.id)).map(r => r.job_id)) : new Set();
  app.innerHTML = `<h1>Teaching opportunities</h1><p class="lede">Posted by schools and families. Only teachers approved by SAPIORA can apply.</p>
  <form class="card" data-form="jobfilter"><div class="grid2"><label>What<input name="q" placeholder="Keyword, subject or title"></label><label>Where<input name="loc" placeholder="City or town"></label>
  <label>Phase<select name="phase"><option value="">Any phase</option>${PHASES.map(p => `<option>${esc(p)}</option>`).join("")}</select></label>
  <label>Format<select name="fmt">${opts(FORMATS, "Any format")}</select></label><label>Job type<select name="type">${opts(JOB_TYPES, "Any type")}</select></label></div></form>
  <p class="muted" id="jobcount"></p><div id="joblist"></div>`;
  const form = app.querySelector("form");
  const draw = () => {
    const v = Object.fromEntries(new FormData(form)), q = v.q.toLowerCase(), loc = v.loc.toLowerCase();
    const rows = jobs.filter(j => (!q || [j.title, j.organisation, j.description, ...j.subjects].join(" ").toLowerCase().includes(q))
      && (!loc || (j.location || "").toLowerCase().includes(loc)) && (!v.phase || j.phases.includes(v.phase))
      && (!v.fmt || j.format === v.fmt || j.format === "either") && (!v.type || j.job_type === v.type));
    document.getElementById("jobcount").textContent = rows.length + (rows.length === 1 ? " opportunity" : " opportunities");
    document.getElementById("joblist").innerHTML = rows.map(j => `<article class="card"><div class="row"><h3><a href="#/jobs/${j.id}">${esc(j.title)}</a></h3>
      ${me?.role === "teacher" ? `<button class="btn btn-outline btn-small" data-act="save" data-id="${j.id}" data-on="${saved.has(j.id) ? 1 : 0}">${saved.has(j.id) ? "Saved" : "Save"}</button>` : ""}</div>
      <small>${jobMeta(j)}</small>${j.pay_text ? `<p><b>${esc(j.pay_text)}</b></p>` : ""}
      <p>${esc(j.description.slice(0, 180))}${j.description.length > 180 ? "..." : ""}</p><div>${jobTags(j)}</div><small>${ago(j.created_at)}</small></article>`).join("")
      || `<p class="muted">No opportunities match your search yet.</p>`;
  };
  draw(); form.addEventListener("input", draw);
}

async function viewJob(id) {
  const j = must(await sb.from("job_posts").select("*").eq("id", id).maybeSingle());
  if (!j) { app.innerHTML = `<h1>Opportunity not found</h1><p class="lede"><a href="#/jobs"><u>Back to all opportunities</u></a></p>`; return; }
  let apply = `<div class="notice"><a href="#/login"><u>Sign in</u></a> as an approved teacher to apply.</div>`;
  if (j.status !== "open") apply = `<div class="notice">This opportunity is ${label(j.status)} and is not accepting applications.${j.status === "rejected" && j.reviewer_notes ? " Reviewer note: " + esc(j.reviewer_notes) : ""}</div>`;
  else if (me?.role === "teacher") {
    const [ta, ex] = await Promise.all([sb.from("teacher_applications").select("review_status").eq("user_id", me.id).maybeSingle(),
      sb.from("job_applications").select("status").eq("job_id", id).eq("teacher_id", me.id).maybeSingle()]).then(r => r.map(must));
    apply = ex ? `<div class="card">Your application: ${tag(label(ex.status), statusClass(ex.status))}</div>`
      : ta?.review_status === "approved" ? `<form class="card" data-form="apply" data-job="${id}"><label>Why are you a good fit?<textarea name="note" rows="5" maxlength="3000" required></textarea></label><button class="btn btn-primary">Apply now</button><p class="err" role="alert"></p></form>`
      : `<div class="notice">You can apply once SAPIORA has approved your credentials. <a href="#/account"><u>Go to your application</u></a></div>`;
  } else if (me) apply = `<div class="notice">Only approved teachers can apply.</div>`;
  app.innerHTML = `<p><a href="#/jobs"><u>All opportunities</u></a></p><h1>${esc(j.title)}</h1><p class="lede">${jobMeta(j)}</p>
  ${j.pay_text ? `<p><b>${esc(j.pay_text)}</b></p>` : ""}<div>${jobTags(j)}</div><div class="card" style="margin-top:16px;white-space:pre-line">${esc(j.description)}</div>
  <small class="muted">Posted ${ago(j.created_at)}${j.closes_on ? " · Closes " + esc(j.closes_on) : ""}</small><h2>Apply</h2>${apply}`;
}

async function teacherJobsHTML() {
  const [apps, sv] = await Promise.all([
    sb.from("job_applications").select("*, job:job_posts(id,title,organisation,status)").eq("teacher_id", me.id).order("created_at", { ascending: false }),
    sb.from("saved_jobs").select("job:job_posts(id,title,organisation,status)").eq("teacher_id", me.id)]).then(r => r.map(must));
  return `<h2>My job applications</h2>` + (apps.map(a => `<div class="card row"><span><a href="#/jobs/${a.job?.id}"><b>${esc(a.job?.title)}</b></a><br><small>${esc(a.job?.organisation)} · ${ago(a.created_at)}</small></span>
    <span>${tag(label(a.status), statusClass(a.status))} ${["submitted", "shortlisted"].includes(a.status) ? `<button class="btn btn-danger btn-small" data-act="withdraw" data-id="${a.id}">Withdraw</button>` : ""}</span></div>`).join("")
    || `<p class="muted">No applications yet. <a href="#/jobs"><u>Browse opportunities</u></a></p>`)
    + `<h2>Saved opportunities</h2>` + (sv.filter(s => s.job).map(s => `<div class="card row"><a href="#/jobs/${s.job.id}"><b>${esc(s.job.title)}</b></a><small>${esc(s.job.organisation)} · ${tag(label(s.job.status), statusClass(s.job.status))}</small></div>`).join("") || `<p class="muted">Nothing saved.</p>`);
}

async function postsHTML() {
  const [posts, apps, dir] = await Promise.all([
    sb.from("job_posts").select("*").eq("poster_id", me.id).order("created_at", { ascending: false }),
    sb.from("job_applications").select("*, t:profiles!teacher_id(email)").order("created_at"),
    sb.from("teacher_public_profiles").select("*")]).then(r => r.map(must));
  const tp = Object.fromEntries(dir.map(d => [d.teacher_id, d]));
  const S = Object.fromEntries(must(await sb.from("platform_settings").select("*")).map(s => [s.key, Number(s.value)]));
  const fee = S.job_post_fee_cents > 0 && (me.role === "school" || !S.job_fee_schools_only) ? ` A posting fee of ${rand(S.job_post_fee_cents)} is payable by EFT once your post is approved.` : "";
  let h = `<h2>Post a teaching opportunity</h2><p class="muted">New posts are reviewed by SAPIORA before they go live.${fee}</p>
  <form class="card" data-form="postjob"><div class="grid2"><label>Job title<input name="title" required minlength="5" maxlength="120" placeholder="e.g. Grade 9 Mathematics tutor"></label>
  <label>School or family name<input name="org" required value="${esc(me.full_name)}"></label><label>Subjects (comma separated)<input name="subjects" required></label>
  <label>Location<input name="loc" placeholder="City or town"></label><label>Format<select name="fmt" required>${opts(FORMATS, "Choose")}</select></label>
  <label>Job type<select name="type" required>${opts(JOB_TYPES, "Choose")}</select></label><label>Pay (optional)<input name="pay" placeholder="e.g. R250 per hour"></label>
  <label>Closing date (optional)<input name="closes" type="date"></label></div>
  <fieldset class="qual"><legend>Phases (tick all that apply)</legend>${PHASES.map(p => `<label><input type="checkbox" name="phases" value="${esc(p)}"> ${esc(p)}</label>`).join("")}</fieldset>
  <label>Description<textarea name="desc" rows="5" required minlength="20" maxlength="5000"></textarea></label><button class="btn btn-primary">Submit for review</button><p class="err" role="alert"></p></form>
  <h2>My opportunities</h2>`;
  h += posts.map(p => {
    const mine = apps.filter(a => a.job_id === p.id);
    return `<div class="card"><div class="row"><h3><a href="#/jobs/${p.id}">${esc(p.title)}</a></h3>${tag(label(p.status), statusClass(p.status))}</div>
    <small>${jobMeta(p)} · ${mine.length} applicant${mine.length === 1 ? "" : "s"}</small>
    ${p.status === "rejected" ? `<div class="notice">Not approved: ${esc(p.reviewer_notes)}</div>` : ""}
    ${p.status === "awaiting_payment" ? `<div class="bank">Approved. Pay the posting fee of ${rand(p.fee_cents)} to ${esc(BANK.holder)}, ${esc(BANK.bank)}, account ${esc(BANK.account)}, branch ${esc(BANK.branch)}.<br><b>Use reference: ${esc(p.fee_reference)}</b>
      ${p.fee_proof_path ? "<br>Proof uploaded. Your post goes live once SAPIORA confirms payment." : `<form data-form="feeproof" data-id="${p.id}"><label>Upload proof of payment<input name="file" type="file" accept=".pdf,image/*" required></label><button class="btn btn-outline btn-small">Upload proof</button></form>`}</div>` : ""}
    ${mine.map(a => { const t = tp[a.teacher_id]; return `<div class="bank"><b>${esc(t?.display_name || "Teacher")}</b> ${tag(label(a.status), statusClass(a.status))}<br>
      <small>${esc(t ? qualSummary(t.qualification_levels, t.qualification_programmes) : "")}</small><p>${esc(a.cover_note)}</p>
      ${a.t?.email ? `<small>Contact: ${esc(a.t.email)}</small>` : `<small>Contact details are shared once you shortlist this teacher.</small>`}
      ${["submitted", "shortlisted"].includes(a.status) ? `<div class="actions">${a.status === "submitted" ? `<button class="btn btn-primary btn-small" data-act="appstatus" data-s="shortlisted" data-id="${a.id}">Shortlist</button>` : ""}
      <button class="btn btn-primary btn-small" data-act="appstatus" data-s="accepted" data-id="${a.id}">Accept</button><button class="btn btn-danger btn-small" data-act="appstatus" data-s="declined" data-id="${a.id}">Decline</button></div>` : ""}</div>`; }).join("")}
    ${["open", "pending_review", "awaiting_payment"].includes(p.status) ? `<div class="actions"><button class="btn btn-outline btn-small" data-act="closejob" data-id="${p.id}">Close opportunity</button></div>` : ""}</div>`;
  }).join("") || `<p class="muted">You have not posted anything yet.</p>`;
  return h;
}

async function loadThread(id) {
  const box = document.getElementById("thread-" + id);
  const msgs = must(await sb.from("booking_messages").select("*").eq("booking_id", id).order("created_at"));
  box.innerHTML = `<div class="msgs">${msgs.map(m => `<div class="msg ${m.sender_id === me.id ? "mine" : ""}"><span>${esc(m.body)}</span><small>${when(m.created_at)}</small></div>`).join("") || '<p class="muted">No messages yet.</p>'}</div>
  <form data-form="msg" data-id="${id}"><label>Message<textarea name="body" rows="2" maxlength="1000" required></textarea></label><button class="btn btn-primary btn-small">Send</button>
  <p class="err" role="alert"></p><small class="muted">Phone numbers, emails and chat links are blocked until the family has paid through SAPIORA.</small></form>`;
}

