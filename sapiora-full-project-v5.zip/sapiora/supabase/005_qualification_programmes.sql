-- SAPIORA 005: specific qualification programmes (run once, after 004)
alter table public.teacher_applications add column if not exists qualification_programmes text[] not null default '{}';
alter table public.teacher_public_profiles add column if not exists qualification_programmes text[] not null default '{}';

create function public.valid_programmes(p text[]) returns boolean language sql immutable as $$
  select coalesce(bool_and(x ~ '^[a-z_]+:[a-z0-9_]+$'), true) and coalesce(array_length(p, 1), 0) <= 60 from unnest(p) x
$$;
alter table public.teacher_applications add constraint app_progs_valid check (public.valid_programmes(qualification_programmes));

-- Approval now also publishes the chosen programmes
create or replace function public.review_application(p_application uuid, p_decision public.teacher_review_status, p_notes text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare a public.teacher_applications; n text;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('in_review','needs_information','approved','rejected') then raise exception 'invalid decision'; end if;
  select * into a from public.teacher_applications where id = p_application for update;
  if not found then raise exception 'application not found'; end if;
  if a.review_status = 'draft' then raise exception 'application not yet submitted'; end if;
  if p_decision in ('needs_information','rejected') and coalesce(trim(p_notes),'') = '' then
    raise exception 'a note is required for this decision';
  end if;

  update public.teacher_applications set review_status = p_decision, reviewer_notes = p_notes,
    reviewed_at = now(), reviewed_by = auth.uid() where id = a.id;

  if p_decision = 'approved' then
    select full_name into n from public.profiles where id = a.user_id;
    insert into public.teacher_public_profiles (teacher_id, display_name, bio, subjects, grades, formats, qualification_levels, qualification_programmes, published)
    values (a.user_id, n, a.professional_bio, a.subjects, a.grades, a.teaching_formats, a.qualification_levels, a.qualification_programmes, true)
    on conflict (teacher_id) do update set display_name = excluded.display_name, bio = excluded.bio,
      subjects = excluded.subjects, grades = excluded.grades, formats = excluded.formats,
      qualification_levels = excluded.qualification_levels,
      qualification_programmes = excluded.qualification_programmes,
      published = true, updated_at = now();
  else  -- any other decision (incl. revoking a prior approval) removes the listing
    update public.teacher_public_profiles set published = false, updated_at = now() where teacher_id = a.user_id;
  end if;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_application', 'teacher_application', a.id,
          jsonb_build_object('from', a.review_status, 'to', p_decision, 'notes', p_notes));
end $$;

revoke execute on function public.review_application from public, anon;
grant execute on function public.review_application to authenticated;
