-- SAPIORA initial Supabase schema
-- Apply only after reviewing the security model and configuring Supabase Storage.
-- Never make qualification documents publicly readable.

create extension if not exists pgcrypto;

create type public.account_role as enum ('teacher', 'parent', 'school', 'admin');
create type public.teacher_review_status as enum ('draft', 'submitted', 'in_review', 'needs_information', 'approved', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.account_role not null,
  full_name text not null,
  email text not null,
  phone text,
  created_at timestamptz not null default now()
);

create table public.teacher_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  professional_bio text,
  subjects text[] not null default '{}',
  grades text[] not null default '{}',
  teaching_formats text[] not null default '{}',
  qualification_summary text,
  sace_number text,
  review_status public.teacher_review_status not null default 'draft',
  reviewer_notes text,
  submitted_at timestamptz,
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.teacher_documents (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.teacher_applications(id) on delete cascade,
  document_type text not null check (document_type in ('identity', 'qualification', 'sace_evidence', 'other')),
  storage_path text not null,
  uploaded_at timestamptz not null default now()
);

create table public.teacher_public_profiles (
  teacher_id uuid primary key references public.profiles(id) on delete cascade,
  display_name text not null,
  bio text,
  subjects text[] not null default '{}',
  grades text[] not null default '{}',
  formats text[] not null default '{}',
  published boolean not null default false,
  updated_at timestamptz not null default now()
);

create table public.organisation_enquiries (
  id uuid primary key default gen_random_uuid(),
  submitted_by uuid not null references public.profiles(id) on delete cascade,
  organisation_name text not null,
  contact_person text not null,
  message text not null,
  status text not null default 'new' check (status in ('new', 'contacted', 'in_discussion', 'closed')),
  created_at timestamptz not null default now()
);

create table public.lesson_enquiries (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid not null references public.profiles(id) on delete cascade,
  teacher_id uuid references public.profiles(id),
  learner_grade text,
  subject text not null,
  learning_format text,
  message text,
  status text not null default 'new' check (status in ('new', 'responded', 'booked', 'closed')),
  created_at timestamptz not null default now()
);

-- Enable RLS. Add carefully scoped policies before connecting a client.
alter table public.profiles enable row level security;
alter table public.teacher_applications enable row level security;
alter table public.teacher_documents enable row level security;
alter table public.teacher_public_profiles enable row level security;
alter table public.organisation_enquiries enable row level security;
alter table public.lesson_enquiries enable row level security;

-- IMPORTANT SECURITY TODO:
-- 1. Add policies so users can read/update only their own profile.
-- 2. Restrict teacher_documents to the document owner and authorised reviewers.
-- 3. Restrict review_status/reviewer_notes/reviewed_by changes to admins using
--    a trusted server-side role check, never a client-supplied role field.
-- 4. Only publish teacher_public_profiles after an admin-approved application.
-- 5. Create a private Storage bucket for credential documents.
-- 6. Do not store raw identity documents longer than necessary.
-- 7. Add audit logs for all admin review decisions.
