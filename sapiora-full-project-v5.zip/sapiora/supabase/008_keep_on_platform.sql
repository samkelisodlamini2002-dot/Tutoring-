-- SAPIORA 008: keep clients on the platform. Run once, after 007.
-- Teachers see a family's name but NOT their email until the lesson is paid through SAPIORA.
-- Messaging is built in; phone numbers, emails and chat links are blocked until payment.

alter table public.bookings add column if not exists requester_name text;
update public.bookings b set requester_name = (select full_name from public.profiles p where p.id = b.requester_id) where requester_name is null;

create or replace function public.guard_booking() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    if not public.is_approved_teacher(new.teacher_id) then raise exception 'teacher is not approved'; end if;
    if new.starts_at < now() then raise exception 'start time is in the past'; end if;
    new.status := 'requested'; new.price_cents := null;
    new.requester_name := (select full_name from public.profiles where id = new.requester_id);
    return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.requester_id <> old.requester_id or new.teacher_id <> old.teacher_id
     or new.starts_at <> old.starts_at or new.ends_at <> old.ends_at
     or new.requester_name is distinct from old.requester_name then
    raise exception 'booking details are fixed; cancel and rebook';
  end if;
  if new.status = old.status then return new; end if;
  if auth.uid() = old.teacher_id and old.status = 'requested' and new.status in ('accepted','declined') then
    if new.status = 'accepted' and new.price_cents is null then raise exception 'price required to accept'; end if;
  elsif auth.uid() = old.teacher_id and old.status = 'accepted' and new.status = 'completed' and now() >= old.ends_at then null;
  elsif old.status in ('requested','accepted') and new.status = 'cancelled' then null;
  else raise exception 'transition % -> % not allowed', old.status, new.status;
  end if;
  return new;
end $$;

-- teachers can no longer read the family's profile row (and email) just because a booking exists
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select using (id = auth.uid() or public.is_admin());

create function public.get_booking_contact(p_booking uuid) returns text
language plpgsql stable security definer set search_path = '' as $$
declare b public.bookings; e text;
begin
  select * into b from public.bookings where id = p_booking;
  if not found then return null; end if;
  if not (auth.uid() = b.teacher_id or public.is_admin()) then return null; end if;
  if not public.is_admin() and not exists (select 1 from public.payments where booking_id = p_booking and status = 'paid') then return null; end if;
  select email into e from public.profiles where id = b.requester_id;
  return e;
end $$;
revoke execute on function public.get_booking_contact from public, anon;
grant execute on function public.get_booking_contact to authenticated;

create table public.booking_messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);
alter table public.booking_messages enable row level security;
create policy msg_read on public.booking_messages for select using (public.is_admin() or exists (
  select 1 from public.bookings b where b.id = booking_id and (b.requester_id = auth.uid() or b.teacher_id = auth.uid())));
create policy msg_insert on public.booking_messages for insert with check (sender_id = auth.uid());
revoke update, delete on public.booking_messages from anon, authenticated;

create function public.guard_message() returns trigger language plpgsql security definer set search_path = '' as $$
declare b public.bookings; paid boolean;
begin
  select * into b from public.bookings where id = new.booking_id;
  if not found or auth.uid() is null or new.sender_id <> auth.uid() or auth.uid() not in (b.requester_id, b.teacher_id) then
    raise exception 'not allowed'; end if;
  if b.status in ('declined','cancelled') then raise exception 'this booking is closed'; end if;
  select exists (select 1 from public.payments where booking_id = b.id and status = 'paid') into paid;
  if not paid and (length(regexp_replace(new.body, '\D', '', 'g')) >= 9
      or new.body ~* '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}' or new.body ~* '(whatsapp|telegram|wa\.me|signal)') then
    raise exception 'Please keep phone numbers, emails and chat links out of messages until the family has paid through SAPIORA.';
  end if;
  return new;
end $$;
create trigger trg_guard_message before insert on public.booking_messages for each row execute function public.guard_message();
