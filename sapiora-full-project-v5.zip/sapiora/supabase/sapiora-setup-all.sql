-- SAPIORA full database setup: run once in Supabase SQL editor (new project)
-- PART 1: base schema
-- SAPIORA initial Supabase schema
-- Apply only after reviewing the security model and configuring Supabase Storage.
-- Never make qualification documents publicly readable.

create extension if not exists pgcrypto;

create type public.account_role as enum ('teacher', 'parent', 'school', 'admin');
create type public.teacher_review_status as enum ('draft', 'submitted', 'in_review', 'needs_information', 'approved', 'rejected');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role public.account_role not null,
  full_name text not null,
  email text not null,
  phone text,
  created_at timestamptz not null default now()
);

create table public.teacher_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null unique references public.profiles(id) on delete cascade,
  professional_bio text,
  subjects text[] not null default '{}',
  grades text[] not null default '{}',
  teaching_formats text[] not null default '{}',
  qualification_summary text,
  sace_number text,
  review_status public.teacher_review_status not null default 'draft',
  reviewer_notes text,
  submitted_at timestamptz,
  reviewed_at timestamptz,
  reviewed_by uuid references public.profiles(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.teacher_documents (
  id uuid primary key default gen_random_uuid(),
  application_id uuid not null references public.teacher_applications(id) on delete cascade,
  document_type text not null check (document_type in ('identity', 'qualification', 'sace_evidence', 'other')),
  storage_path text not null,
  uploaded_at timestamptz not null default now()
);

create table public.teacher_public_profiles (
  teacher_id uuid primary key references public.profiles(id) on delete cascade,
  display_name text not null,
  bio text,
  subjects text[] not null default '{}',
  grades text[] not null default '{}',
  formats text[] not null default '{}',
  published boolean not null default false,
  updated_at timestamptz not null default now()
);

create table public.organisation_enquiries (
  id uuid primary key default gen_random_uuid(),
  submitted_by uuid not null references public.profiles(id) on delete cascade,
  organisation_name text not null,
  contact_person text not null,
  message text not null,
  status text not null default 'new' check (status in ('new', 'contacted', 'in_discussion', 'closed')),
  created_at timestamptz not null default now()
);

create table public.lesson_enquiries (
  id uuid primary key default gen_random_uuid(),
  parent_id uuid not null references public.profiles(id) on delete cascade,
  teacher_id uuid references public.profiles(id),
  learner_grade text,
  subject text not null,
  learning_format text,
  message text,
  status text not null default 'new' check (status in ('new', 'responded', 'booked', 'closed')),
  created_at timestamptz not null default now()
);

-- Enable RLS. Add carefully scoped policies before connecting a client.
alter table public.profiles enable row level security;
alter table public.teacher_applications enable row level security;
alter table public.teacher_documents enable row level security;
alter table public.teacher_public_profiles enable row level security;
alter table public.organisation_enquiries enable row level security;
alter table public.lesson_enquiries enable row level security;

-- IMPORTANT SECURITY TODO:
-- 1. Add policies so users can read/update only their own profile.
-- 2. Restrict teacher_documents to the document owner and authorised reviewers.
-- 3. Restrict review_status/reviewer_notes/reviewed_by changes to admins using
--    a trusted server-side role check, never a client-supplied role field.
-- 4. Only publish teacher_public_profiles after an admin-approved application.
-- 5. Create a private Storage bucket for credential documents.
-- 6. Do not store raw identity documents longer than necessary.
-- 7. Add audit logs for all admin review decisions.

-- PART 2: platform core
-- SAPIORA platform core (run AFTER 001 / schema.sql)
-- Principle enforced in the database, not the browser:
--   NO TEACHER IS PUBLIC UNTIL AN ADMIN HAS APPROVED THEIR CREDENTIALS.
-- First admin: after signing up, run once in the SQL editor:
--   update public.profiles set role='admin' where email='you@yourdomain';

-- ---------- helpers ----------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create or replace function public.is_approved_teacher(t uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.teacher_applications where user_id = t and review_status = 'approved');
$$;

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid, action text not null, entity text not null, entity_id uuid,
  details jsonb not null default '{}', created_at timestamptz not null default now()
);
alter table public.audit_log enable row level security;
create policy audit_admin_read on public.audit_log for select using (public.is_admin());
revoke insert, update, delete on public.audit_log from anon, authenticated;

-- ---------- profiles ----------
create policy profiles_insert on public.profiles for insert
  with check (id = auth.uid() and role in ('teacher','parent','school'));
create policy profiles_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

create function public.guard_profile() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null and not public.is_admin() then
    raise exception 'role cannot be changed' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger trg_guard_profile before update on public.profiles for each row execute function public.guard_profile();

-- ---------- teacher applications ----------
alter table public.teacher_applications add column if not exists hourly_rate_cents int check (hourly_rate_cents > 0);

create policy app_owner_read on public.teacher_applications for select using (user_id = auth.uid() or public.is_admin());
create policy app_owner_insert on public.teacher_applications for insert with check (
  user_id = auth.uid() and review_status = 'draft' and reviewer_notes is null and reviewed_by is null
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'teacher'));
create policy app_owner_update on public.teacher_applications for update
  using (user_id = auth.uid()) with check (user_id = auth.uid());
-- Admins change applications ONLY through review_application() below.

create function public.guard_application() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.updated_at := now();
  if auth.uid() is null or public.is_admin() then return new; end if;
  if old.review_status not in ('draft','needs_information') then
    raise exception 'application is locked while under review or decided';
  end if;
  if new.review_status not in (old.review_status, 'submitted') then
    raise exception 'invalid status change';
  end if;
  if new.user_id <> old.user_id or new.reviewer_notes is distinct from old.reviewer_notes
     or new.reviewed_by is distinct from old.reviewed_by or new.reviewed_at is distinct from old.reviewed_at then
    raise exception 'review fields are admin-only';
  end if;
  if new.review_status = 'submitted' then
    if not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'identity')
       or not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'qualification') then
      raise exception 'identity and qualification documents are required';
    end if;
    new.submitted_at := now();
  end if;
  return new;
end $$;
create trigger trg_guard_application before update on public.teacher_applications
  for each row execute function public.guard_application();

-- ---------- credential documents (private) ----------
create policy docs_read on public.teacher_documents for select using (
  public.is_admin() or exists (select 1 from public.teacher_applications a where a.id = application_id and a.user_id = auth.uid()));
create policy docs_insert on public.teacher_documents for insert with check (
  storage_path like auth.uid()::text || '/%' and exists (
    select 1 from public.teacher_applications a where a.id = application_id and a.user_id = auth.uid()
      and a.review_status in ('draft','needs_information')));
create policy docs_delete on public.teacher_documents for delete using (
  exists (select 1 from public.teacher_applications a where a.id = application_id and a.user_id = auth.uid()
      and a.review_status in ('draft','needs_information')));

insert into storage.buckets (id, name, public) values ('credentials','credentials', false) on conflict (id) do nothing;
create policy cred_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'credentials' and (storage.foldername(name))[1] = auth.uid()::text);
create policy cred_read on storage.objects for select to authenticated
  using (bucket_id = 'credentials' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- ---------- public directory: approved + published only ----------
create policy directory_public on public.teacher_public_profiles for select to anon, authenticated
  using (published and public.is_approved_teacher(teacher_id));
revoke insert, update, delete on public.teacher_public_profiles from anon, authenticated;

-- ---------- admin decision (the ONLY way a teacher becomes public) ----------
create function public.review_application(p_application uuid, p_decision public.teacher_review_status, p_notes text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare a public.teacher_applications; n text;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('in_review','needs_information','approved','rejected') then raise exception 'invalid decision'; end if;
  select * into a from public.teacher_applications where id = p_application for update;
  if not found then raise exception 'application not found'; end if;
  if a.review_status = 'draft' then raise exception 'application not yet submitted'; end if;
  if p_decision in ('needs_information','rejected') and coalesce(trim(p_notes),'') = '' then
    raise exception 'a note is required for this decision';
  end if;

  update public.teacher_applications set review_status = p_decision, reviewer_notes = p_notes,
    reviewed_at = now(), reviewed_by = auth.uid() where id = a.id;

  if p_decision = 'approved' then
    select full_name into n from public.profiles where id = a.user_id;
    insert into public.teacher_public_profiles (teacher_id, display_name, bio, subjects, grades, formats, published)
    values (a.user_id, n, a.professional_bio, a.subjects, a.grades, a.teaching_formats, true)
    on conflict (teacher_id) do update set display_name = excluded.display_name, bio = excluded.bio,
      subjects = excluded.subjects, grades = excluded.grades, formats = excluded.formats,
      published = true, updated_at = now();
  else  -- any other decision (incl. revoking a prior approval) removes the listing
    update public.teacher_public_profiles set published = false, updated_at = now() where teacher_id = a.user_id;
  end if;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_application', 'teacher_application', a.id,
          jsonb_build_object('from', a.review_status, 'to', p_decision, 'notes', p_notes));
end $$;

-- ---------- bookings (parents and schools) ----------
create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id),
  teacher_id uuid not null references public.profiles(id),
  subject text not null, learner_grade text, learning_format text, message text,
  starts_at timestamptz not null, ends_at timestamptz not null check (ends_at > starts_at),
  status text not null default 'requested'
    check (status in ('requested','accepted','declined','cancelled','completed')),
  price_cents int check (price_cents > 0), currency text not null default 'ZAR',
  cancel_reason text, created_at timestamptz not null default now()
);
alter table public.bookings enable row level security;
create policy bk_read on public.bookings for select
  using (requester_id = auth.uid() or teacher_id = auth.uid() or public.is_admin());
create policy bk_insert on public.bookings for insert with check (
  requester_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('parent','school')));
create policy bk_update on public.bookings for update using (requester_id = auth.uid() or teacher_id = auth.uid());

-- (needs bookings table, so defined here)
create policy profiles_read on public.profiles for select
  using (id = auth.uid() or public.is_admin()
    or exists (select 1 from public.bookings b where (b.requester_id = profiles.id and b.teacher_id = auth.uid())));
create function public.guard_booking() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    if not public.is_approved_teacher(new.teacher_id) then raise exception 'teacher is not approved'; end if;
    if new.starts_at < now() then raise exception 'start time is in the past'; end if;
    new.status := 'requested'; new.price_cents := null; return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.requester_id <> old.requester_id or new.teacher_id <> old.teacher_id
     or new.starts_at <> old.starts_at or new.ends_at <> old.ends_at then
    raise exception 'booking details are fixed; cancel and rebook';
  end if;
  if new.status = old.status then return new; end if;
  if auth.uid() = old.teacher_id and old.status = 'requested' and new.status in ('accepted','declined') then
    if new.status = 'accepted' and new.price_cents is null then raise exception 'price required to accept'; end if;
  elsif auth.uid() = old.teacher_id and old.status = 'accepted' and new.status = 'completed' and now() >= old.ends_at then null;
  elsif old.status in ('requested','accepted') and new.status = 'cancelled' then null;
  else raise exception 'transition % -> % not allowed', old.status, new.status;
  end if;
  return new;
end $$;
create trigger trg_guard_booking before insert or update on public.bookings
  for each row execute function public.guard_booking();

-- ---------- payments & payouts (written by server/webhooks only) ----------
create table public.payouts (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id),
  amount_cents int not null check (amount_cents > 0), currency text not null default 'ZAR',
  status text not null default 'pending' check (status in ('pending','approved','paid','failed')),
  approved_by uuid references public.profiles(id), provider_ref text,
  created_at timestamptz not null default now(), paid_at timestamptz
);
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id),
  payer_id uuid not null references public.profiles(id),
  amount_cents int not null check (amount_cents > 0),
  platform_fee_cents int not null default 0 check (platform_fee_cents >= 0),
  currency text not null default 'ZAR', provider text not null,
  provider_ref text unique, payout_id uuid references public.payouts(id),
  status text not null default 'pending' check (status in ('pending','paid','failed','refunded')),
  created_at timestamptz not null default now()
);
alter table public.payments enable row level security;
alter table public.payouts enable row level security;
create policy pay_read on public.payments for select using (
  payer_id = auth.uid() or public.is_admin()
  or exists (select 1 from public.bookings b where b.id = booking_id and b.teacher_id = auth.uid()));
create policy payout_read on public.payouts for select using (teacher_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.payments, public.payouts from anon, authenticated;

create function public.set_payout_status(p_payout uuid, p_status text, p_ref text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare p public.payouts;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_status not in ('approved','paid','failed') then raise exception 'invalid status'; end if;
  select * into p from public.payouts where id = p_payout for update;
  if not found then raise exception 'payout not found'; end if;
  if not public.is_approved_teacher(p.teacher_id) then raise exception 'teacher is not approved'; end if;
  if p_status = 'approved' and p.status <> 'pending' then raise exception 'only pending payouts can be approved'; end if;
  if p_status = 'paid' and p.status <> 'approved' then raise exception 'approve before paying'; end if;
  update public.payouts set status = p_status, provider_ref = coalesce(p_ref, provider_ref),
    approved_by = case when p_status = 'approved' then auth.uid() else approved_by end,
    paid_at = case when p_status = 'paid' then now() else paid_at end where id = p.id;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'payout_' || p_status, 'payout', p.id, jsonb_build_object('ref', p_ref));
end $$;

-- ---------- function permissions ----------
revoke execute on function public.review_application, public.set_payout_status from public, anon;
grant execute on function public.review_application, public.set_payout_status to authenticated;

-- PART 3: EFT payments
-- SAPIORA EFT payments (run after 002). Parents/schools pay by bank transfer,
-- upload proof, admin confirms receipt, admin then pays teachers out manually.
alter table public.payments add column if not exists proof_path text;
alter table public.payments alter column provider set default 'eft';

insert into storage.buckets (id, name, public) values ('eft-proofs','eft-proofs', false) on conflict (id) do nothing;
create policy proof_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'eft-proofs' and (storage.foldername(name))[1] = auth.uid()::text);
create policy proof_read on storage.objects for select to authenticated
  using (bucket_id = 'eft-proofs' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- Requester asks for payment details on an accepted booking. Platform fee: 10% (edit here).
create function public.create_eft_payment(p_booking uuid) returns public.payments
language plpgsql security definer set search_path = '' as $$
declare b public.bookings; r public.payments;
begin
  select * into b from public.bookings where id = p_booking;
  if not found or b.requester_id <> auth.uid() then raise exception 'booking not found'; end if;
  if b.status <> 'accepted' or b.price_cents is null then raise exception 'booking is not ready for payment'; end if;
  select * into r from public.payments where booking_id = b.id and status in ('pending','paid') limit 1;
  if found then return r; end if;
  insert into public.payments (booking_id, payer_id, amount_cents, platform_fee_cents, currency, provider)
  values (b.id, b.requester_id, b.price_cents, round(b.price_cents * 0.10), b.currency, 'eft') returning * into r;
  update public.payments set provider_ref = 'SAP-' || upper(substr(r.id::text, 1, 8)) where id = r.id returning * into r;
  return r;
end $$;

create function public.attach_eft_proof(p_payment uuid, p_path text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if p_path not like auth.uid()::text || '/%' then raise exception 'invalid path'; end if;
  update public.payments set proof_path = p_path where id = p_payment and payer_id = auth.uid() and status = 'pending';
  if not found then raise exception 'payment not found'; end if;
end $$;

create function public.confirm_eft_payment(p_payment uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  update public.payments set status = 'paid' where id = p_payment and status = 'pending';
  if not found then raise exception 'payment not pending'; end if;
  insert into public.audit_log (actor_id, action, entity, entity_id) values (auth.uid(), 'confirm_eft', 'payment', p_payment);
end $$;

-- Bundle a teacher's paid, completed, not-yet-paid-out lessons into one payout (amount minus fee).
create function public.create_payout(p_teacher uuid) returns uuid
language plpgsql security definer set search_path = '' as $$
declare total int; pid uuid;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if not public.is_approved_teacher(p_teacher) then raise exception 'teacher is not approved'; end if;
  select coalesce(sum(p.amount_cents - p.platform_fee_cents), 0) into total from public.payments p
    join public.bookings b on b.id = p.booking_id
   where b.teacher_id = p_teacher and b.status = 'completed' and p.status = 'paid' and p.payout_id is null;
  if total <= 0 then raise exception 'nothing to pay out'; end if;
  insert into public.payouts (teacher_id, amount_cents) values (p_teacher, total) returning id into pid;
  update public.payments p set payout_id = pid from public.bookings b
   where b.id = p.booking_id and b.teacher_id = p_teacher and b.status = 'completed' and p.status = 'paid' and p.payout_id is null;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'create_payout', 'payout', pid, jsonb_build_object('amount_cents', total));
  return pid;
end $$;

revoke execute on function public.create_eft_payment, public.attach_eft_proof, public.confirm_eft_payment, public.create_payout from public, anon;
grant execute on function public.create_eft_payment, public.attach_eft_proof, public.confirm_eft_payment, public.create_payout to authenticated;

-- PART 4: qualification levels
-- SAPIORA 004: teaching qualification levels (run once, after 003)
alter table public.teacher_applications add column if not exists qualification_levels text[] not null default '{}';
alter table public.teacher_applications add constraint app_levels_valid check (
  qualification_levels <@ array['higher_certificate','diploma','bed','pgce','ace','advanced_diploma','honours','masters','doctorate','other']::text[]);
alter table public.teacher_public_profiles add column if not exists qualification_levels text[] not null default '{}';

-- Submission now requires at least one qualification level
create or replace function public.guard_application() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.updated_at := now();
  if auth.uid() is null or public.is_admin() then return new; end if;
  if old.review_status not in ('draft','needs_information') then
    raise exception 'application is locked while under review or decided';
  end if;
  if new.review_status not in (old.review_status, 'submitted') then
    raise exception 'invalid status change';
  end if;
  if new.user_id <> old.user_id or new.reviewer_notes is distinct from old.reviewer_notes
     or new.reviewed_by is distinct from old.reviewed_by or new.reviewed_at is distinct from old.reviewed_at then
    raise exception 'review fields are admin-only';
  end if;
  if new.review_status = 'submitted' then
    if coalesce(array_length(new.qualification_levels, 1), 0) = 0 then raise exception 'select at least one teaching qualification'; end if;
    if not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'identity')
       or not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'qualification') then
      raise exception 'identity and qualification documents are required';
    end if;
    new.submitted_at := now();
  end if;
  return new;
end $$;

-- Approval now publishes the declared qualification levels
create or replace function public.review_application(p_application uuid, p_decision public.teacher_review_status, p_notes text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare a public.teacher_applications; n text;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('in_review','needs_information','approved','rejected') then raise exception 'invalid decision'; end if;
  select * into a from public.teacher_applications where id = p_application for update;
  if not found then raise exception 'application not found'; end if;
  if a.review_status = 'draft' then raise exception 'application not yet submitted'; end if;
  if p_decision in ('needs_information','rejected') and coalesce(trim(p_notes),'') = '' then
    raise exception 'a note is required for this decision';
  end if;

  update public.teacher_applications set review_status = p_decision, reviewer_notes = p_notes,
    reviewed_at = now(), reviewed_by = auth.uid() where id = a.id;

  if p_decision = 'approved' then
    select full_name into n from public.profiles where id = a.user_id;
    insert into public.teacher_public_profiles (teacher_id, display_name, bio, subjects, grades, formats, qualification_levels, published)
    values (a.user_id, n, a.professional_bio, a.subjects, a.grades, a.teaching_formats, a.qualification_levels, true)
    on conflict (teacher_id) do update set display_name = excluded.display_name, bio = excluded.bio,
      subjects = excluded.subjects, grades = excluded.grades, formats = excluded.formats,
      qualification_levels = excluded.qualification_levels,
      published = true, updated_at = now();
  else  -- any other decision (incl. revoking a prior approval) removes the listing
    update public.teacher_public_profiles set published = false, updated_at = now() where teacher_id = a.user_id;
  end if;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_application', 'teacher_application', a.id,
          jsonb_build_object('from', a.review_status, 'to', p_decision, 'notes', p_notes));
end $$;

revoke execute on function public.review_application from public, anon;
grant execute on function public.review_application to authenticated;

-- PART 5: qualification programmes
-- SAPIORA 005: specific qualification programmes (run once, after 004)
alter table public.teacher_applications add column if not exists qualification_programmes text[] not null default '{}';
alter table public.teacher_public_profiles add column if not exists qualification_programmes text[] not null default '{}';

create function public.valid_programmes(p text[]) returns boolean language sql immutable as $$
  select coalesce(bool_and(x ~ '^[a-z_]+:[a-z0-9_]+$'), true) and coalesce(array_length(p, 1), 0) <= 60 from unnest(p) x
$$;
alter table public.teacher_applications add constraint app_progs_valid check (public.valid_programmes(qualification_programmes));

-- Approval now also publishes the chosen programmes
create or replace function public.review_application(p_application uuid, p_decision public.teacher_review_status, p_notes text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare a public.teacher_applications; n text;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('in_review','needs_information','approved','rejected') then raise exception 'invalid decision'; end if;
  select * into a from public.teacher_applications where id = p_application for update;
  if not found then raise exception 'application not found'; end if;
  if a.review_status = 'draft' then raise exception 'application not yet submitted'; end if;
  if p_decision in ('needs_information','rejected') and coalesce(trim(p_notes),'') = '' then
    raise exception 'a note is required for this decision';
  end if;

  update public.teacher_applications set review_status = p_decision, reviewer_notes = p_notes,
    reviewed_at = now(), reviewed_by = auth.uid() where id = a.id;

  if p_decision = 'approved' then
    select full_name into n from public.profiles where id = a.user_id;
    insert into public.teacher_public_profiles (teacher_id, display_name, bio, subjects, grades, formats, qualification_levels, qualification_programmes, published)
    values (a.user_id, n, a.professional_bio, a.subjects, a.grades, a.teaching_formats, a.qualification_levels, a.qualification_programmes, true)
    on conflict (teacher_id) do update set display_name = excluded.display_name, bio = excluded.bio,
      subjects = excluded.subjects, grades = excluded.grades, formats = excluded.formats,
      qualification_levels = excluded.qualification_levels,
      qualification_programmes = excluded.qualification_programmes,
      published = true, updated_at = now();
  else  -- any other decision (incl. revoking a prior approval) removes the listing
    update public.teacher_public_profiles set published = false, updated_at = now() where teacher_id = a.user_id;
  end if;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_application', 'teacher_application', a.id,
          jsonb_build_object('from', a.review_status, 'to', p_decision, 'notes', p_notes));
end $$;

revoke execute on function public.review_application from public, anon;
grant execute on function public.review_application to authenticated;

-- PART 6: opportunities
-- SAPIORA 006: teaching opportunities (Indeed-style job board). Run once, after 005.
-- Rules: posts are moderated before going live; ONLY admin-approved teachers can apply;
-- applicant contact details are shared with a poster only after they shortlist or accept.

create table public.job_posts (
  id uuid primary key default gen_random_uuid(),
  poster_id uuid not null references public.profiles(id),
  organisation text not null,
  title text not null check (char_length(title) between 5 and 120),
  description text not null check (char_length(description) between 20 and 5000),
  subjects text[] not null default '{}', phases text[] not null default '{}',
  format text not null check (format in ('online','in_person','either')),
  location text,
  job_type text not null check (job_type in ('tutoring','part_time','full_time','holiday_class','contract')),
  pay_text text, closes_on date,
  status text not null default 'pending_review' check (status in ('pending_review','open','rejected','closed')),
  reviewer_notes text, reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
create table public.job_applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.job_posts(id) on delete cascade,
  teacher_id uuid not null references public.profiles(id),
  cover_note text check (char_length(cover_note) <= 3000),
  status text not null default 'submitted' check (status in ('submitted','shortlisted','declined','accepted','withdrawn')),
  created_at timestamptz not null default now(),
  unique (job_id, teacher_id)
);
create table public.saved_jobs (
  teacher_id uuid not null references public.profiles(id),
  job_id uuid not null references public.job_posts(id) on delete cascade,
  primary key (teacher_id, job_id)
);
alter table public.job_posts enable row level security;
alter table public.job_applications enable row level security;
alter table public.saved_jobs enable row level security;

create function public.is_job_poster(j uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.job_posts where id = j and poster_id = auth.uid());
$$;
create function public.can_see_applicant(t uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.job_applications a join public.job_posts j on j.id = a.job_id
    where a.teacher_id = t and j.poster_id = auth.uid() and a.status in ('shortlisted','accepted'));
$$;

-- job posts
create policy jobs_public_read on public.job_posts for select to anon, authenticated
  using (status = 'open' and (closes_on is null or closes_on >= current_date));
create policy jobs_owner_read on public.job_posts for select using (poster_id = auth.uid() or public.is_admin());
create policy jobs_insert on public.job_posts for insert with check (
  poster_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('parent','school')));
create policy jobs_update on public.job_posts for update using (poster_id = auth.uid()) with check (poster_id = auth.uid());

create function public.guard_job() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    new.status := 'pending_review'; new.reviewer_notes := null; new.reviewed_at := null; return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.reviewer_notes is distinct from old.reviewer_notes or new.reviewed_at is distinct from old.reviewed_at
     or new.poster_id <> old.poster_id then raise exception 'review fields are admin-only'; end if;
  if new.status is distinct from old.status then
    if not (old.status in ('open','pending_review') and new.status = 'closed') then raise exception 'invalid status change'; end if;
  elsif row(new.title, new.description, new.organisation, new.subjects, new.phases, new.format, new.location, new.job_type, new.pay_text)
        is distinct from row(old.title, old.description, old.organisation, old.subjects, old.phases, old.format, old.location, old.job_type, old.pay_text) then
    if old.status = 'closed' then raise exception 'closed posts cannot be edited'; end if;
    new.status := 'pending_review';  -- edits to a live post are re-reviewed
  end if;
  return new;
end $$;
create trigger trg_guard_job before insert or update on public.job_posts for each row execute function public.guard_job();

create function public.review_job(p_job uuid, p_decision text, p_notes text default null) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('open','rejected') then raise exception 'invalid decision'; end if;
  if p_decision = 'rejected' and coalesce(trim(p_notes), '') = '' then raise exception 'a reason is required'; end if;
  update public.job_posts set status = p_decision, reviewer_notes = p_notes, reviewed_at = now()
   where id = p_job and status in ('pending_review','open','rejected');
  if not found then raise exception 'post not found or closed'; end if;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_job', 'job_post', p_job, jsonb_build_object('decision', p_decision, 'notes', p_notes));
end $$;
revoke execute on function public.review_job from public, anon;
grant execute on function public.review_job to authenticated;

-- applications
create policy apps_read on public.job_applications for select
  using (teacher_id = auth.uid() or public.is_admin() or public.is_job_poster(job_id));
create policy apps_insert on public.job_applications for insert with check (teacher_id = auth.uid());
create policy apps_update on public.job_applications for update
  using (teacher_id = auth.uid() or public.is_job_poster(job_id));

create function public.guard_application_job() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    if not public.is_approved_teacher(new.teacher_id) then raise exception 'only approved teachers can apply'; end if;
    if not exists (select 1 from public.job_posts where id = new.job_id and status = 'open' and (closes_on is null or closes_on >= current_date)) then
      raise exception 'this opportunity is not open'; end if;
    new.status := 'submitted'; return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.job_id <> old.job_id or new.teacher_id <> old.teacher_id or new.cover_note is distinct from old.cover_note then
    raise exception 'application details cannot be changed'; end if;
  if new.status = old.status then return new; end if;
  if auth.uid() = old.teacher_id then
    if not (old.status in ('submitted','shortlisted') and new.status = 'withdrawn') then raise exception 'invalid status change'; end if;
  elsif public.is_job_poster(old.job_id) then
    if not ((old.status = 'submitted' and new.status in ('shortlisted','declined','accepted'))
         or (old.status = 'shortlisted' and new.status in ('accepted','declined'))) then raise exception 'invalid status change'; end if;
  else raise exception 'not allowed'; end if;
  return new;
end $$;
create trigger trg_guard_application_job before insert or update on public.job_applications
  for each row execute function public.guard_application_job();

create policy saved_own on public.saved_jobs for all using (teacher_id = auth.uid()) with check (teacher_id = auth.uid());

-- a poster may read an applicant's contact details only after shortlisting or accepting them
create policy profiles_read_applicant on public.profiles for select using (public.can_see_applicant(id));

-- PART 7: fees
-- SAPIORA 007: admin-editable fees + opportunity posting fees paid by EFT. Run once, after 006.
create table public.platform_settings (key text primary key, value numeric not null, updated_at timestamptz not null default now());
insert into public.platform_settings (key, value) values ('fee_percent', 10), ('job_post_fee_cents', 0), ('job_fee_schools_only', 1);
alter table public.platform_settings enable row level security;
create policy settings_read on public.platform_settings for select to anon, authenticated using (true);
revoke insert, update, delete on public.platform_settings from anon, authenticated;

create function public.set_setting(p_key text, p_value numeric) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if not ((p_key = 'fee_percent' and p_value between 0 and 50)
       or (p_key = 'job_post_fee_cents' and p_value between 0 and 10000000)
       or (p_key = 'job_fee_schools_only' and p_value in (0, 1))) then raise exception 'invalid setting'; end if;
  update public.platform_settings set value = p_value, updated_at = now() where key = p_key;
  insert into public.audit_log (actor_id, action, entity, details) values (auth.uid(), 'set_setting', 'setting', jsonb_build_object('key', p_key, 'value', p_value));
end $$;
revoke execute on function public.set_setting from public, anon;
grant execute on function public.set_setting to authenticated;

-- lesson fee now follows the setting
create or replace function public.create_eft_payment(p_booking uuid) returns public.payments
language plpgsql security definer set search_path = '' as $$
declare b public.bookings; r public.payments;
begin
  select * into b from public.bookings where id = p_booking;
  if not found or b.requester_id <> auth.uid() then raise exception 'booking not found'; end if;
  if b.status <> 'accepted' or b.price_cents is null then raise exception 'booking is not ready for payment'; end if;
  select * into r from public.payments where booking_id = b.id and status in ('pending','paid') limit 1;
  if found then return r; end if;
  insert into public.payments (booking_id, payer_id, amount_cents, platform_fee_cents, currency, provider)
  values (b.id, b.requester_id, b.price_cents, round(b.price_cents * coalesce((select value from public.platform_settings where key = 'fee_percent'), 10) / 100), b.currency, 'eft') returning * into r;
  update public.payments set provider_ref = 'SAP-' || upper(substr(r.id::text, 1, 8)) where id = r.id returning * into r;
  return r;
end $$;

-- posting fees
alter table public.job_posts add column if not exists fee_cents int not null default 0;
alter table public.job_posts add column if not exists fee_paid_at timestamptz;
alter table public.job_posts add column if not exists fee_reference text;
alter table public.job_posts add column if not exists fee_proof_path text;
alter table public.job_posts drop constraint if exists job_posts_status_check;
alter table public.job_posts add constraint job_posts_status_check check (status in ('pending_review','awaiting_payment','open','rejected','closed'));

create or replace function public.guard_job() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    new.status := 'pending_review'; new.reviewer_notes := null; new.reviewed_at := null;
    new.fee_cents := 0; new.fee_paid_at := null; new.fee_reference := null; new.fee_proof_path := null; return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.reviewer_notes is distinct from old.reviewer_notes or new.reviewed_at is distinct from old.reviewed_at
     or new.poster_id <> old.poster_id or new.fee_cents is distinct from old.fee_cents
     or new.fee_paid_at is distinct from old.fee_paid_at or new.fee_reference is distinct from old.fee_reference then
    raise exception 'review and fee fields are admin-only'; end if;
  if new.fee_proof_path is distinct from old.fee_proof_path and
     (new.fee_proof_path is null or new.fee_proof_path not like auth.uid()::text || '/%' or old.status <> 'awaiting_payment') then
    raise exception 'invalid proof of payment'; end if;
  if new.status is distinct from old.status then
    if not (old.status in ('open','pending_review','awaiting_payment') and new.status = 'closed') then raise exception 'invalid status change'; end if;
  elsif row(new.title, new.description, new.organisation, new.subjects, new.phases, new.format, new.location, new.job_type, new.pay_text)
        is distinct from row(old.title, old.description, old.organisation, old.subjects, old.phases, old.format, old.location, old.job_type, old.pay_text) then
    if old.status = 'closed' then raise exception 'closed posts cannot be edited'; end if;
    new.status := 'pending_review';
  end if;
  return new;
end $$;

-- approval now routes to awaiting_payment when a fee applies and has not been paid
create or replace function public.review_job(p_job uuid, p_decision text, p_notes text default null) returns void
language plpgsql security definer set search_path = '' as $$
declare j public.job_posts; fee int; so numeric; prole text; s text;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('open','rejected') then raise exception 'invalid decision'; end if;
  if p_decision = 'rejected' and coalesce(trim(p_notes), '') = '' then raise exception 'a reason is required'; end if;
  select * into j from public.job_posts where id = p_job for update;
  if not found or j.status = 'closed' then raise exception 'post not found or closed'; end if;
  if p_decision = 'rejected' then s := 'rejected';
  else
    select coalesce((select value from public.platform_settings where key = 'job_post_fee_cents'), 0)::int into fee;
    select coalesce((select value from public.platform_settings where key = 'job_fee_schools_only'), 1) into so;
    select role::text into prole from public.profiles where id = j.poster_id;
    s := case when j.fee_paid_at is null and fee > 0 and (so = 0 or prole = 'school') then 'awaiting_payment' else 'open' end;
  end if;
  update public.job_posts set status = s, reviewer_notes = p_notes, reviewed_at = now(),
    fee_cents = case when s = 'awaiting_payment' then fee else fee_cents end,
    fee_reference = case when s = 'awaiting_payment' then coalesce(fee_reference, 'JOB-' || upper(substr(id::text, 1, 8))) else fee_reference end
   where id = p_job;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_job', 'job_post', p_job, jsonb_build_object('decision', p_decision, 'result', s, 'notes', p_notes));
end $$;

create function public.confirm_job_fee(p_job uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  update public.job_posts set fee_paid_at = now(), status = 'open' where id = p_job and status = 'awaiting_payment' and fee_proof_path is not null;
  if not found then raise exception 'no payment awaiting confirmation'; end if;
  insert into public.audit_log (actor_id, action, entity, entity_id) values (auth.uid(), 'confirm_job_fee', 'job_post', p_job);
end $$;
revoke execute on function public.confirm_job_fee from public, anon;
grant execute on function public.confirm_job_fee to authenticated;

-- PART 8: keep clients on platform
-- SAPIORA 008: keep clients on the platform. Run once, after 007.
-- Teachers see a family's name but NOT their email until the lesson is paid through SAPIORA.
-- Messaging is built in; phone numbers, emails and chat links are blocked until payment.

alter table public.bookings add column if not exists requester_name text;
update public.bookings b set requester_name = (select full_name from public.profiles p where p.id = b.requester_id) where requester_name is null;

create or replace function public.guard_booking() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    if not public.is_approved_teacher(new.teacher_id) then raise exception 'teacher is not approved'; end if;
    if new.starts_at < now() then raise exception 'start time is in the past'; end if;
    new.status := 'requested'; new.price_cents := null;
    new.requester_name := (select full_name from public.profiles where id = new.requester_id);
    return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.requester_id <> old.requester_id or new.teacher_id <> old.teacher_id
     or new.starts_at <> old.starts_at or new.ends_at <> old.ends_at
     or new.requester_name is distinct from old.requester_name then
    raise exception 'booking details are fixed; cancel and rebook';
  end if;
  if new.status = old.status then return new; end if;
  if auth.uid() = old.teacher_id and old.status = 'requested' and new.status in ('accepted','declined') then
    if new.status = 'accepted' and new.price_cents is null then raise exception 'price required to accept'; end if;
  elsif auth.uid() = old.teacher_id and old.status = 'accepted' and new.status = 'completed' and now() >= old.ends_at then null;
  elsif old.status in ('requested','accepted') and new.status = 'cancelled' then null;
  else raise exception 'transition % -> % not allowed', old.status, new.status;
  end if;
  return new;
end $$;

-- teachers can no longer read the family's profile row (and email) just because a booking exists
drop policy if exists profiles_read on public.profiles;
create policy profiles_read on public.profiles for select using (id = auth.uid() or public.is_admin());

create function public.get_booking_contact(p_booking uuid) returns text
language plpgsql stable security definer set search_path = '' as $$
declare b public.bookings; e text;
begin
  select * into b from public.bookings where id = p_booking;
  if not found then return null; end if;
  if not (auth.uid() = b.teacher_id or public.is_admin()) then return null; end if;
  if not public.is_admin() and not exists (select 1 from public.payments where booking_id = p_booking and status = 'paid') then return null; end if;
  select email into e from public.profiles where id = b.requester_id;
  return e;
end $$;
revoke execute on function public.get_booking_contact from public, anon;
grant execute on function public.get_booking_contact to authenticated;

create table public.booking_messages (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  sender_id uuid not null references public.profiles(id),
  body text not null check (char_length(body) between 1 and 1000),
  created_at timestamptz not null default now()
);
alter table public.booking_messages enable row level security;
create policy msg_read on public.booking_messages for select using (public.is_admin() or exists (
  select 1 from public.bookings b where b.id = booking_id and (b.requester_id = auth.uid() or b.teacher_id = auth.uid())));
create policy msg_insert on public.booking_messages for insert with check (sender_id = auth.uid());
revoke update, delete on public.booking_messages from anon, authenticated;

create function public.guard_message() returns trigger language plpgsql security definer set search_path = '' as $$
declare b public.bookings; paid boolean;
begin
  select * into b from public.bookings where id = new.booking_id;
  if not found or auth.uid() is null or new.sender_id <> auth.uid() or auth.uid() not in (b.requester_id, b.teacher_id) then
    raise exception 'not allowed'; end if;
  if b.status in ('declined','cancelled') then raise exception 'this booking is closed'; end if;
  select exists (select 1 from public.payments where booking_id = b.id and status = 'paid') into paid;
  if not paid and (length(regexp_replace(new.body, '\D', '', 'g')) >= 9
      or new.body ~* '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}' or new.body ~* '(whatsapp|telegram|wa\.me|signal)') then
    raise exception 'Please keep phone numbers, emails and chat links out of messages until the family has paid through SAPIORA.';
  end if;
  return new;
end $$;
create trigger trg_guard_message before insert on public.booking_messages for each row execute function public.guard_message();

-- PART 9: protect fees
-- SAPIORA 009: make it hard to bypass the platform fee. Run once, after 008.
-- 1) Public profile text, job posts and cover notes cannot carry phone numbers, emails or chat links.
-- 2) A lesson cannot be marked completed until the family has paid through SAPIORA.

create function public.has_contact_details(t text) returns boolean language sql immutable as $$
  select coalesce(length(regexp_replace(t, '\D', '', 'g')) >= 9
      or t ~* '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}'
      or t ~* '(whatsapp|telegram|wa\.me|signal|https?://|www\.)', false);
$$;

create function public.guard_contact_text() returns trigger language plpgsql security definer set search_path = '' as $$
declare t text;
begin
  if auth.uid() is null or public.is_admin() then return new; end if;
  if tg_table_name = 'teacher_applications' then t := concat_ws(' ', new.professional_bio, new.qualification_summary);
  elsif tg_table_name = 'job_applications' then t := new.cover_note;
  elsif tg_table_name = 'job_posts' then t := concat_ws(' ', new.title, new.organisation, new.description, new.pay_text);
  end if;
  if public.has_contact_details(t) then
    raise exception 'Please remove phone numbers, emails, web links and chat links from this text. Contact details are shared through SAPIORA after payment.';
  end if;
  return new;
end $$;
create trigger trg_contact_text before insert or update on public.teacher_applications for each row execute function public.guard_contact_text();
create trigger trg_contact_text before insert or update on public.job_applications for each row execute function public.guard_contact_text();
create trigger trg_contact_text before insert or update on public.job_posts for each row execute function public.guard_contact_text();

create function public.guard_completion() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.status = 'completed' and old.status is distinct from 'completed' and auth.uid() is not null and not public.is_admin()
     and not exists (select 1 from public.payments where booking_id = new.id and status = 'paid') then
    raise exception 'The family must pay through SAPIORA before this lesson can be marked completed.';
  end if;
  return new;
end $$;
create trigger trg_guard_completion before update on public.bookings for each row execute function public.guard_completion();

-- PART 10: terms acceptance
-- SAPIORA 010: teachers must accept the Teacher Services Agreement before submitting. Run once, after 009.
alter table public.teacher_applications
  add column if not exists terms_version text check (char_length(terms_version) <= 40),
  add column if not exists terms_accepted_at timestamptz;

create function public.guard_terms() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  -- the acceptance time is always set by the server, never by the browser
  if new.terms_version is distinct from old.terms_version then
    new.terms_accepted_at := case when new.terms_version is null then null else now() end;
  else
    new.terms_accepted_at := old.terms_accepted_at;
  end if;
  if new.review_status = 'submitted' and old.review_status is distinct from 'submitted' and new.terms_version is null
     and auth.uid() is not null and not public.is_admin() then
    raise exception 'You must accept the Teacher Services Agreement before submitting.';
  end if;
  return new;
end $$;
create trigger trg_guard_terms before update on public.teacher_applications for each row execute function public.guard_terms();

-- PART 11: verification team
-- SAPIORA 011: verification team. Run once, after 010.
-- Verifiers can read applications and documents and approve, reject or request information on submitted applications.
-- The administrator sees who verified each teacher and can reject (revoke) afterwards.

create table public.verifiers (user_id uuid primary key references public.profiles(id), added_by uuid references public.profiles(id), created_at timestamptz not null default now());
alter table public.verifiers enable row level security;
create function public.is_verifier() returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.verifiers where user_id = auth.uid());
$$;
create policy verifiers_read on public.verifiers for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.verifiers from anon, authenticated;

alter table public.teacher_applications add column if not exists verified_by uuid references public.profiles(id), add column if not exists verified_at timestamptz;

create policy app_verifier_read on public.teacher_applications for select using (public.is_verifier());
create policy docs_verifier_read on public.teacher_documents for select using (public.is_verifier());
create policy cred_verifier_read on storage.objects for select to authenticated using (bucket_id = 'credentials' and public.is_verifier());
create function public.verifier_can_see(t uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select public.is_verifier() and exists (select 1 from public.teacher_applications where user_id = t);
$$;
create policy profiles_verifier_read on public.profiles for select using (public.verifier_can_see(id));

-- verifiers may update an application they do not own (a verifier cannot approve themselves)
create or replace function public.guard_application() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.updated_at := now();
  if auth.uid() is null or public.is_admin() or (public.is_verifier() and new.user_id <> auth.uid()) then return new; end if;
  if old.review_status not in ('draft','needs_information') then
    raise exception 'application is locked while under review or decided';
  end if;
  if new.review_status not in (old.review_status, 'submitted') then
    raise exception 'invalid status change';
  end if;
  if new.user_id <> old.user_id or new.reviewer_notes is distinct from old.reviewer_notes
     or new.reviewed_by is distinct from old.reviewed_by or new.reviewed_at is distinct from old.reviewed_at then
    raise exception 'review fields are admin-only';
  end if;
  if new.review_status = 'submitted' then
    if coalesce(array_length(new.qualification_levels, 1), 0) = 0 then raise exception 'select at least one teaching qualification'; end if;
    if not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'identity')
       or not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'qualification') then
      raise exception 'identity and qualification documents are required';
    end if;
    new.submitted_at := now();
  end if;
  return new;
end $$;

-- review_application now accepts verifiers (submitted/in-review applications only) as well as the administrator
create or replace function public.review_application(p_application uuid, p_decision public.teacher_review_status, p_notes text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare a public.teacher_applications; n text;
begin
  if not (public.is_admin() or public.is_verifier()) then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_decision not in ('in_review','needs_information','approved','rejected') then raise exception 'invalid decision'; end if;
  select * into a from public.teacher_applications where id = p_application for update;
  if not found then raise exception 'application not found'; end if;
  if a.review_status = 'draft' then raise exception 'application not yet submitted'; end if;
  if not public.is_admin() then
    if a.user_id = auth.uid() then raise exception 'you cannot review your own application'; end if;
    if a.review_status not in ('submitted','in_review') then raise exception 'this application has already been decided; ask the administrator'; end if;
  end if;
  if p_decision in ('needs_information','rejected') and coalesce(trim(p_notes),'') = '' then
    raise exception 'a note is required for this decision';
  end if;

  update public.teacher_applications set review_status = p_decision, reviewer_notes = p_notes,
    reviewed_at = now(), reviewed_by = auth.uid(),
    verified_by = case when p_decision = 'approved' then auth.uid() else verified_by end,
    verified_at = case when p_decision = 'approved' then now() else verified_at end where id = a.id;

  if p_decision = 'approved' then
    select full_name into n from public.profiles where id = a.user_id;
    insert into public.teacher_public_profiles (teacher_id, display_name, bio, subjects, grades, formats, qualification_levels, qualification_programmes, published)
    values (a.user_id, n, a.professional_bio, a.subjects, a.grades, a.teaching_formats, a.qualification_levels, a.qualification_programmes, true)
    on conflict (teacher_id) do update set display_name = excluded.display_name, bio = excluded.bio,
      subjects = excluded.subjects, grades = excluded.grades, formats = excluded.formats,
      qualification_levels = excluded.qualification_levels,
      qualification_programmes = excluded.qualification_programmes,
      published = true, updated_at = now();
  else  -- any other decision (incl. revoking a prior approval) removes the listing
    update public.teacher_public_profiles set published = false, updated_at = now() where teacher_id = a.user_id;
  end if;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_application', 'teacher_application', a.id,
          jsonb_build_object('from', a.review_status, 'to', p_decision, 'notes', p_notes));
end $$;

create function public.add_verifier(p_email text) returns void language plpgsql security definer set search_path = '' as $$
declare u uuid;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  select id into u from public.profiles where lower(email) = lower(trim(p_email));
  if not found then raise exception 'No account with that email. Ask them to sign up first.'; end if;
  insert into public.verifiers (user_id, added_by) values (u, auth.uid()) on conflict do nothing;
  insert into public.audit_log (actor_id, action, entity, entity_id) values (auth.uid(), 'add_verifier', 'profile', u);
end $$;
create function public.remove_verifier(p_user uuid) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  delete from public.verifiers where user_id = p_user;
  insert into public.audit_log (actor_id, action, entity, entity_id) values (auth.uid(), 'remove_verifier', 'profile', p_user);
end $$;
revoke execute on function public.add_verifier, public.remove_verifier from public, anon;
grant execute on function public.add_verifier, public.remove_verifier to authenticated;

-- PART 12: verifier limits
-- SAPIORA 012: limit what the verification team can see. Run once, after 011.
-- Verifiers see only applications that have been submitted (or that they decided themselves),
-- with those applicants' documents and names. Drafts, other tables and other files stay hidden.

create or replace function public.verifier_can_see_app(a uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select public.is_verifier() and exists (select 1 from public.teacher_applications t
    where t.id = a and (t.review_status in ('submitted','in_review') or t.reviewed_by = auth.uid()));
$$;
create or replace function public.verifier_can_see(t uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select public.is_verifier() and exists (select 1 from public.teacher_applications a
    where a.user_id = t and (a.review_status in ('submitted','in_review') or a.reviewed_by = auth.uid()));
$$;
create function public.verifier_can_see_user_text(t text) returns boolean language sql stable security definer set search_path = '' as $$
  select public.is_verifier() and exists (select 1 from public.teacher_applications a
    where a.user_id::text = t and (a.review_status in ('submitted','in_review') or a.reviewed_by = auth.uid()));
$$;

drop policy if exists app_verifier_read on public.teacher_applications;
create policy app_verifier_read on public.teacher_applications for select
  using (public.is_verifier() and (review_status in ('submitted','in_review') or reviewed_by = auth.uid()));

drop policy if exists docs_verifier_read on public.teacher_documents;
create policy docs_verifier_read on public.teacher_documents for select using (public.verifier_can_see_app(application_id));

drop policy if exists cred_verifier_read on storage.objects;
create policy cred_verifier_read on storage.objects for select to authenticated
  using (bucket_id = 'credentials' and public.verifier_can_see_user_text((storage.foldername(name))[1]));

drop policy if exists profiles_verifier_read on public.profiles;
create policy profiles_verifier_read on public.profiles for select using (public.verifier_can_see(id));
