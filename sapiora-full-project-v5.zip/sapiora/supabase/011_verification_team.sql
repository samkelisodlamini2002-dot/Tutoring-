-- SAPIORA 011: verification team. Run once, after 010.
-- Verifiers can read applications and documents and approve, reject or request information on submitted applications.
-- The administrator sees who verified each teacher and can reject (revoke) afterwards.

create table public.verifiers (user_id uuid primary key references public.profiles(id), added_by uuid references public.profiles(id), created_at timestamptz not null default now());
alter table public.verifiers enable row level security;
create function public.is_verifier() returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.verifiers where user_id = auth.uid());
$$;
create policy verifiers_read on public.verifiers for select using (user_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.verifiers from anon, authenticated;

alter table public.teacher_applications add column if not exists verified_by uuid references public.profiles(id), add column if not exists verified_at timestamptz;

create policy app_verifier_read on public.teacher_applications for select using (public.is_verifier());
create policy docs_verifier_read on public.teacher_documents for select using (public.is_verifier());
create policy cred_verifier_read on storage.objects for select to authenticated using (bucket_id = 'credentials' and public.is_verifier());
create function public.verifier_can_see(t uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select public.is_verifier() and exists (select 1 from public.teacher_applications where user_id = t);
$$;
create policy profiles_verifier_read on public.profiles for select using (public.verifier_can_see(id));

-- verifiers may update an application they do not own (a verifier cannot approve themselves)
create or replace function public.guard_application() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.updated_at := now();
  if auth.uid() is null or public.is_admin() or (public.is_verifier() and new.user_id <> auth.uid()) then return new; end if;
  if old.review_status not in ('draft','needs_information') then
    raise exception 'application is locked while under review or decided';
  end if;
  if new.review_status not in (old.review_status, 'submitted') then
    raise exception 'invalid status change';
  end if;
  if new.user_id <> old.user_id or new.reviewer_notes is distinct from old.reviewer_notes
     or new.reviewed_by is distinct from old.reviewed_by or new.reviewed_at is distinct from old.reviewed_at then
    raise exception 'review fields are admin-only';
  end if;
  if new.review_status = 'submitted' then
    if coalesce(array_length(new.qualification_levels, 1), 0) = 0 then raise exception 'select at least one teaching qualification'; end if;
    if not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'identity')
       or not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'qualification') then
      raise exception 'identity and qualification documents are required';
    end if;
    new.submitted_at := now();
  end if;
  return new;
end $$;

-- review_application now accepts verifiers (submitted/in-review applications only) as well as the administrator
create or replace function public.review_application(p_application uuid, p_decision public.teacher_review_status, p_notes text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare a public.teacher_applications; n text;
begin
  if not (public.is_admin() or public.is_verifier()) then raise exception 'not allowed' using errcode = '42501'; end if;
  if p_decision not in ('in_review','needs_information','approved','rejected') then raise exception 'invalid decision'; end if;
  select * into a from public.teacher_applications where id = p_application for update;
  if not found then raise exception 'application not found'; end if;
  if a.review_status = 'draft' then raise exception 'application not yet submitted'; end if;
  if not public.is_admin() then
    if a.user_id = auth.uid() then raise exception 'you cannot review your own application'; end if;
    if a.review_status not in ('submitted','in_review') then raise exception 'this application has already been decided; ask the administrator'; end if;
  end if;
  if p_decision in ('needs_information','rejected') and coalesce(trim(p_notes),'') = '' then
    raise exception 'a note is required for this decision';
  end if;

  update public.teacher_applications set review_status = p_decision, reviewer_notes = p_notes,
    reviewed_at = now(), reviewed_by = auth.uid(),
    verified_by = case when p_decision = 'approved' then auth.uid() else verified_by end,
    verified_at = case when p_decision = 'approved' then now() else verified_at end where id = a.id;

  if p_decision = 'approved' then
    select full_name into n from public.profiles where id = a.user_id;
    insert into public.teacher_public_profiles (teacher_id, display_name, bio, subjects, grades, formats, qualification_levels, qualification_programmes, published)
    values (a.user_id, n, a.professional_bio, a.subjects, a.grades, a.teaching_formats, a.qualification_levels, a.qualification_programmes, true)
    on conflict (teacher_id) do update set display_name = excluded.display_name, bio = excluded.bio,
      subjects = excluded.subjects, grades = excluded.grades, formats = excluded.formats,
      qualification_levels = excluded.qualification_levels,
      qualification_programmes = excluded.qualification_programmes,
      published = true, updated_at = now();
  else  -- any other decision (incl. revoking a prior approval) removes the listing
    update public.teacher_public_profiles set published = false, updated_at = now() where teacher_id = a.user_id;
  end if;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_application', 'teacher_application', a.id,
          jsonb_build_object('from', a.review_status, 'to', p_decision, 'notes', p_notes));
end $$;

create function public.add_verifier(p_email text) returns void language plpgsql security definer set search_path = '' as $$
declare u uuid;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  select id into u from public.profiles where lower(email) = lower(trim(p_email));
  if not found then raise exception 'No account with that email. Ask them to sign up first.'; end if;
  insert into public.verifiers (user_id, added_by) values (u, auth.uid()) on conflict do nothing;
  insert into public.audit_log (actor_id, action, entity, entity_id) values (auth.uid(), 'add_verifier', 'profile', u);
end $$;
create function public.remove_verifier(p_user uuid) returns void language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  delete from public.verifiers where user_id = p_user;
  insert into public.audit_log (actor_id, action, entity, entity_id) values (auth.uid(), 'remove_verifier', 'profile', p_user);
end $$;
revoke execute on function public.add_verifier, public.remove_verifier from public, anon;
grant execute on function public.add_verifier, public.remove_verifier to authenticated;
