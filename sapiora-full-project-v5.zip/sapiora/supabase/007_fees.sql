-- SAPIORA 007: admin-editable fees + opportunity posting fees paid by EFT. Run once, after 006.
create table public.platform_settings (key text primary key, value numeric not null, updated_at timestamptz not null default now());
insert into public.platform_settings (key, value) values ('fee_percent', 10), ('job_post_fee_cents', 0), ('job_fee_schools_only', 1);
alter table public.platform_settings enable row level security;
create policy settings_read on public.platform_settings for select to anon, authenticated using (true);
revoke insert, update, delete on public.platform_settings from anon, authenticated;

create function public.set_setting(p_key text, p_value numeric) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if not ((p_key = 'fee_percent' and p_value between 0 and 50)
       or (p_key = 'job_post_fee_cents' and p_value between 0 and 10000000)
       or (p_key = 'job_fee_schools_only' and p_value in (0, 1))) then raise exception 'invalid setting'; end if;
  update public.platform_settings set value = p_value, updated_at = now() where key = p_key;
  insert into public.audit_log (actor_id, action, entity, details) values (auth.uid(), 'set_setting', 'setting', jsonb_build_object('key', p_key, 'value', p_value));
end $$;
revoke execute on function public.set_setting from public, anon;
grant execute on function public.set_setting to authenticated;

-- lesson fee now follows the setting
create or replace function public.create_eft_payment(p_booking uuid) returns public.payments
language plpgsql security definer set search_path = '' as $$
declare b public.bookings; r public.payments;
begin
  select * into b from public.bookings where id = p_booking;
  if not found or b.requester_id <> auth.uid() then raise exception 'booking not found'; end if;
  if b.status <> 'accepted' or b.price_cents is null then raise exception 'booking is not ready for payment'; end if;
  select * into r from public.payments where booking_id = b.id and status in ('pending','paid') limit 1;
  if found then return r; end if;
  insert into public.payments (booking_id, payer_id, amount_cents, platform_fee_cents, currency, provider)
  values (b.id, b.requester_id, b.price_cents, round(b.price_cents * coalesce((select value from public.platform_settings where key = 'fee_percent'), 10) / 100), b.currency, 'eft') returning * into r;
  update public.payments set provider_ref = 'SAP-' || upper(substr(r.id::text, 1, 8)) where id = r.id returning * into r;
  return r;
end $$;

-- posting fees
alter table public.job_posts add column if not exists fee_cents int not null default 0;
alter table public.job_posts add column if not exists fee_paid_at timestamptz;
alter table public.job_posts add column if not exists fee_reference text;
alter table public.job_posts add column if not exists fee_proof_path text;
alter table public.job_posts drop constraint if exists job_posts_status_check;
alter table public.job_posts add constraint job_posts_status_check check (status in ('pending_review','awaiting_payment','open','rejected','closed'));

create or replace function public.guard_job() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    new.status := 'pending_review'; new.reviewer_notes := null; new.reviewed_at := null;
    new.fee_cents := 0; new.fee_paid_at := null; new.fee_reference := null; new.fee_proof_path := null; return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.reviewer_notes is distinct from old.reviewer_notes or new.reviewed_at is distinct from old.reviewed_at
     or new.poster_id <> old.poster_id or new.fee_cents is distinct from old.fee_cents
     or new.fee_paid_at is distinct from old.fee_paid_at or new.fee_reference is distinct from old.fee_reference then
    raise exception 'review and fee fields are admin-only'; end if;
  if new.fee_proof_path is distinct from old.fee_proof_path and
     (new.fee_proof_path is null or new.fee_proof_path not like auth.uid()::text || '/%' or old.status <> 'awaiting_payment') then
    raise exception 'invalid proof of payment'; end if;
  if new.status is distinct from old.status then
    if not (old.status in ('open','pending_review','awaiting_payment') and new.status = 'closed') then raise exception 'invalid status change'; end if;
  elsif row(new.title, new.description, new.organisation, new.subjects, new.phases, new.format, new.location, new.job_type, new.pay_text)
        is distinct from row(old.title, old.description, old.organisation, old.subjects, old.phases, old.format, old.location, old.job_type, old.pay_text) then
    if old.status = 'closed' then raise exception 'closed posts cannot be edited'; end if;
    new.status := 'pending_review';
  end if;
  return new;
end $$;

-- approval now routes to awaiting_payment when a fee applies and has not been paid
create or replace function public.review_job(p_job uuid, p_decision text, p_notes text default null) returns void
language plpgsql security definer set search_path = '' as $$
declare j public.job_posts; fee int; so numeric; prole text; s text;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('open','rejected') then raise exception 'invalid decision'; end if;
  if p_decision = 'rejected' and coalesce(trim(p_notes), '') = '' then raise exception 'a reason is required'; end if;
  select * into j from public.job_posts where id = p_job for update;
  if not found or j.status = 'closed' then raise exception 'post not found or closed'; end if;
  if p_decision = 'rejected' then s := 'rejected';
  else
    select coalesce((select value from public.platform_settings where key = 'job_post_fee_cents'), 0)::int into fee;
    select coalesce((select value from public.platform_settings where key = 'job_fee_schools_only'), 1) into so;
    select role::text into prole from public.profiles where id = j.poster_id;
    s := case when j.fee_paid_at is null and fee > 0 and (so = 0 or prole = 'school') then 'awaiting_payment' else 'open' end;
  end if;
  update public.job_posts set status = s, reviewer_notes = p_notes, reviewed_at = now(),
    fee_cents = case when s = 'awaiting_payment' then fee else fee_cents end,
    fee_reference = case when s = 'awaiting_payment' then coalesce(fee_reference, 'JOB-' || upper(substr(id::text, 1, 8))) else fee_reference end
   where id = p_job;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_job', 'job_post', p_job, jsonb_build_object('decision', p_decision, 'result', s, 'notes', p_notes));
end $$;

create function public.confirm_job_fee(p_job uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  update public.job_posts set fee_paid_at = now(), status = 'open' where id = p_job and status = 'awaiting_payment' and fee_proof_path is not null;
  if not found then raise exception 'no payment awaiting confirmation'; end if;
  insert into public.audit_log (actor_id, action, entity, entity_id) values (auth.uid(), 'confirm_job_fee', 'job_post', p_job);
end $$;
revoke execute on function public.confirm_job_fee from public, anon;
grant execute on function public.confirm_job_fee to authenticated;
