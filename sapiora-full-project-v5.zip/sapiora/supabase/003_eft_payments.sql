-- SAPIORA EFT payments (run after 002). Parents/schools pay by bank transfer,
-- upload proof, admin confirms receipt, admin then pays teachers out manually.
alter table public.payments add column if not exists proof_path text;
alter table public.payments alter column provider set default 'eft';

insert into storage.buckets (id, name, public) values ('eft-proofs','eft-proofs', false) on conflict (id) do nothing;
create policy proof_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'eft-proofs' and (storage.foldername(name))[1] = auth.uid()::text);
create policy proof_read on storage.objects for select to authenticated
  using (bucket_id = 'eft-proofs' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- Requester asks for payment details on an accepted booking. Platform fee: 10% (edit here).
create function public.create_eft_payment(p_booking uuid) returns public.payments
language plpgsql security definer set search_path = '' as $$
declare b public.bookings; r public.payments;
begin
  select * into b from public.bookings where id = p_booking;
  if not found or b.requester_id <> auth.uid() then raise exception 'booking not found'; end if;
  if b.status <> 'accepted' or b.price_cents is null then raise exception 'booking is not ready for payment'; end if;
  select * into r from public.payments where booking_id = b.id and status in ('pending','paid') limit 1;
  if found then return r; end if;
  insert into public.payments (booking_id, payer_id, amount_cents, platform_fee_cents, currency, provider)
  values (b.id, b.requester_id, b.price_cents, round(b.price_cents * 0.10), b.currency, 'eft') returning * into r;
  update public.payments set provider_ref = 'SAP-' || upper(substr(r.id::text, 1, 8)) where id = r.id returning * into r;
  return r;
end $$;

create function public.attach_eft_proof(p_payment uuid, p_path text) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if p_path not like auth.uid()::text || '/%' then raise exception 'invalid path'; end if;
  update public.payments set proof_path = p_path where id = p_payment and payer_id = auth.uid() and status = 'pending';
  if not found then raise exception 'payment not found'; end if;
end $$;

create function public.confirm_eft_payment(p_payment uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  update public.payments set status = 'paid' where id = p_payment and status = 'pending';
  if not found then raise exception 'payment not pending'; end if;
  insert into public.audit_log (actor_id, action, entity, entity_id) values (auth.uid(), 'confirm_eft', 'payment', p_payment);
end $$;

-- Bundle a teacher's paid, completed, not-yet-paid-out lessons into one payout (amount minus fee).
create function public.create_payout(p_teacher uuid) returns uuid
language plpgsql security definer set search_path = '' as $$
declare total int; pid uuid;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if not public.is_approved_teacher(p_teacher) then raise exception 'teacher is not approved'; end if;
  select coalesce(sum(p.amount_cents - p.platform_fee_cents), 0) into total from public.payments p
    join public.bookings b on b.id = p.booking_id
   where b.teacher_id = p_teacher and b.status = 'completed' and p.status = 'paid' and p.payout_id is null;
  if total <= 0 then raise exception 'nothing to pay out'; end if;
  insert into public.payouts (teacher_id, amount_cents) values (p_teacher, total) returning id into pid;
  update public.payments p set payout_id = pid from public.bookings b
   where b.id = p.booking_id and b.teacher_id = p_teacher and b.status = 'completed' and p.status = 'paid' and p.payout_id is null;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'create_payout', 'payout', pid, jsonb_build_object('amount_cents', total));
  return pid;
end $$;

revoke execute on function public.create_eft_payment, public.attach_eft_proof, public.confirm_eft_payment, public.create_payout from public, anon;
grant execute on function public.create_eft_payment, public.attach_eft_proof, public.confirm_eft_payment, public.create_payout to authenticated;
