-- SAPIORA 012: limit what the verification team can see. Run once, after 011.
-- Verifiers see only applications that have been submitted (or that they decided themselves),
-- with those applicants' documents and names. Drafts, other tables and other files stay hidden.

create or replace function public.verifier_can_see_app(a uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select public.is_verifier() and exists (select 1 from public.teacher_applications t
    where t.id = a and (t.review_status in ('submitted','in_review') or t.reviewed_by = auth.uid()));
$$;
create or replace function public.verifier_can_see(t uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select public.is_verifier() and exists (select 1 from public.teacher_applications a
    where a.user_id = t and (a.review_status in ('submitted','in_review') or a.reviewed_by = auth.uid()));
$$;
create function public.verifier_can_see_user_text(t text) returns boolean language sql stable security definer set search_path = '' as $$
  select public.is_verifier() and exists (select 1 from public.teacher_applications a
    where a.user_id::text = t and (a.review_status in ('submitted','in_review') or a.reviewed_by = auth.uid()));
$$;

drop policy if exists app_verifier_read on public.teacher_applications;
create policy app_verifier_read on public.teacher_applications for select
  using (public.is_verifier() and (review_status in ('submitted','in_review') or reviewed_by = auth.uid()));

drop policy if exists docs_verifier_read on public.teacher_documents;
create policy docs_verifier_read on public.teacher_documents for select using (public.verifier_can_see_app(application_id));

drop policy if exists cred_verifier_read on storage.objects;
create policy cred_verifier_read on storage.objects for select to authenticated
  using (bucket_id = 'credentials' and public.verifier_can_see_user_text((storage.foldername(name))[1]));

drop policy if exists profiles_verifier_read on public.profiles;
create policy profiles_verifier_read on public.profiles for select using (public.verifier_can_see(id));
