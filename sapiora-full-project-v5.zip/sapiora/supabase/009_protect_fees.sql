-- SAPIORA 009: make it hard to bypass the platform fee. Run once, after 008.
-- 1) Public profile text, job posts and cover notes cannot carry phone numbers, emails or chat links.
-- 2) A lesson cannot be marked completed until the family has paid through SAPIORA.

create function public.has_contact_details(t text) returns boolean language sql immutable as $$
  select coalesce(length(regexp_replace(t, '\D', '', 'g')) >= 9
      or t ~* '[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}'
      or t ~* '(whatsapp|telegram|wa\.me|signal|https?://|www\.)', false);
$$;

create function public.guard_contact_text() returns trigger language plpgsql security definer set search_path = '' as $$
declare t text;
begin
  if auth.uid() is null or public.is_admin() then return new; end if;
  if tg_table_name = 'teacher_applications' then t := concat_ws(' ', new.professional_bio, new.qualification_summary);
  elsif tg_table_name = 'job_applications' then t := new.cover_note;
  elsif tg_table_name = 'job_posts' then t := concat_ws(' ', new.title, new.organisation, new.description, new.pay_text);
  end if;
  if public.has_contact_details(t) then
    raise exception 'Please remove phone numbers, emails, web links and chat links from this text. Contact details are shared through SAPIORA after payment.';
  end if;
  return new;
end $$;
create trigger trg_contact_text before insert or update on public.teacher_applications for each row execute function public.guard_contact_text();
create trigger trg_contact_text before insert or update on public.job_applications for each row execute function public.guard_contact_text();
create trigger trg_contact_text before insert or update on public.job_posts for each row execute function public.guard_contact_text();

create function public.guard_completion() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.status = 'completed' and old.status is distinct from 'completed' and auth.uid() is not null and not public.is_admin()
     and not exists (select 1 from public.payments where booking_id = new.id and status = 'paid') then
    raise exception 'The family must pay through SAPIORA before this lesson can be marked completed.';
  end if;
  return new;
end $$;
create trigger trg_guard_completion before update on public.bookings for each row execute function public.guard_completion();
