-- SAPIORA 014: verification checks (what the team has actually verified for each teacher).
-- Run once, after 011 and 012 (needs verifier_can_see from 012).

-- 1. Allow a police clearance certificate as a document type.
do $$ declare c text; begin
  for c in select conname from pg_constraint
    where conrelid = 'public.teacher_documents'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%document_type%'
  loop execute format('alter table public.teacher_documents drop constraint %I', c); end loop;
end $$;
alter table public.teacher_documents add constraint teacher_documents_document_type_check
  check (document_type in ('identity', 'qualification', 'sace_evidence', 'police_clearance', 'other'));

-- 2. Approved teachers may add a police clearance later (other documents stay locked after approval).
drop policy if exists docs_insert_clearance on public.teacher_documents;
create policy docs_insert_clearance on public.teacher_documents for insert with check (
  document_type = 'police_clearance' and storage_path like auth.uid()::text || '/%'
  and exists (select 1 from public.teacher_applications a where a.id = application_id and a.user_id = auth.uid()
    and a.review_status in ('draft', 'needs_information', 'approved')));

-- 3. The checks themselves. Only the verification team can change them (through set_teacher_check).
create table if not exists public.teacher_checks (
  teacher_id uuid not null references public.profiles(id) on delete cascade,
  check_type text not null check (check_type in ('identity', 'qualification', 'sace', 'police_clearance')),
  verified_at timestamptz not null default now(),
  expires_on date,
  primary key (teacher_id, check_type)
);
alter table public.teacher_checks enable row level security;
revoke all on public.teacher_checks from anon, authenticated;
grant select on public.teacher_checks to anon, authenticated;

drop policy if exists checks_public_read on public.teacher_checks;
create policy checks_public_read on public.teacher_checks for select to anon, authenticated
  using (exists (select 1 from public.teacher_public_profiles p where p.teacher_id = teacher_checks.teacher_id and p.published));
drop policy if exists checks_own_read on public.teacher_checks;
create policy checks_own_read on public.teacher_checks for select to authenticated using (teacher_id = auth.uid());
drop policy if exists checks_staff_read on public.teacher_checks;
create policy checks_staff_read on public.teacher_checks for select to authenticated
  using (public.is_admin() or public.verifier_can_see(teacher_id));

-- 4. Staff set or remove a check. Admins, or a verifier for applications they can see. Never your own.
create or replace function public.set_teacher_check(p_teacher uuid, p_type text, p_verified boolean, p_expires date default null)
returns void language plpgsql security definer set search_path = '' as $$
declare v_exp date := p_expires;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if not (public.is_admin() or public.verifier_can_see(p_teacher)) then raise exception 'not allowed'; end if;
  if p_teacher = auth.uid() then raise exception 'you cannot verify your own checks'; end if;
  if p_type not in ('identity', 'qualification', 'sace', 'police_clearance') then raise exception 'unknown check'; end if;
  if not exists (select 1 from public.profiles where id = p_teacher and role = 'teacher') then raise exception 'not a teacher'; end if;
  if p_verified then
    if p_type in ('identity', 'qualification') then v_exp := null; end if;
    if p_type = 'police_clearance' and v_exp is null then raise exception 'enter the date the police clearance is valid until'; end if;
    if v_exp is not null and v_exp <= current_date then raise exception 'the valid-until date must be in the future'; end if;
    insert into public.teacher_checks (teacher_id, check_type, verified_at, expires_on) values (p_teacher, p_type, now(), v_exp)
      on conflict (teacher_id, check_type) do update set verified_at = now(), expires_on = excluded.expires_on;
  else
    delete from public.teacher_checks where teacher_id = p_teacher and check_type = p_type;
  end if;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
    values (auth.uid(), 'set_teacher_check', 'profile', p_teacher, jsonb_build_object('type', p_type, 'verified', p_verified, 'expires_on', v_exp));
end $$;
revoke execute on function public.set_teacher_check from public, anon;
grant execute on function public.set_teacher_check to authenticated;

-- OPTIONAL backfill: mark identity and qualification as verified for teachers who were approved
-- before this migration (approval already required both documents). Remove the dashes to run.
-- insert into public.teacher_checks (teacher_id, check_type, verified_at)
--   select a.user_id, c.t, coalesce(a.reviewed_at, now()) from public.teacher_applications a
--   cross join (values ('identity'), ('qualification')) as c(t)
--   where a.review_status = 'approved' on conflict do nothing;
