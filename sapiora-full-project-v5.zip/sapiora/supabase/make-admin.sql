-- Run AFTER you have signed up, confirmed your email and signed in once.
update public.profiles
set role = 'admin'
where lower(email) = 'vilerolaacademy@outlook.com';
