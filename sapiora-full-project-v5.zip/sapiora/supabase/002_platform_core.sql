-- SAPIORA platform core (run AFTER 001 / schema.sql)
-- Principle enforced in the database, not the browser:
--   NO TEACHER IS PUBLIC UNTIL AN ADMIN HAS APPROVED THEIR CREDENTIALS.
-- First admin: after signing up, run once in the SQL editor:
--   update public.profiles set role='admin' where email='you@yourdomain';

-- ---------- helpers ----------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

create or replace function public.is_approved_teacher(t uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.teacher_applications where user_id = t and review_status = 'approved');
$$;

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid, action text not null, entity text not null, entity_id uuid,
  details jsonb not null default '{}', created_at timestamptz not null default now()
);
alter table public.audit_log enable row level security;
create policy audit_admin_read on public.audit_log for select using (public.is_admin());
revoke insert, update, delete on public.audit_log from anon, authenticated;

-- ---------- profiles ----------
create policy profiles_insert on public.profiles for insert
  with check (id = auth.uid() and role in ('teacher','parent','school'));
create policy profiles_update on public.profiles for update using (id = auth.uid()) with check (id = auth.uid());

create function public.guard_profile() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if new.role is distinct from old.role and auth.uid() is not null and not public.is_admin() then
    raise exception 'role cannot be changed' using errcode = '42501';
  end if;
  return new;
end $$;
create trigger trg_guard_profile before update on public.profiles for each row execute function public.guard_profile();

-- ---------- teacher applications ----------
alter table public.teacher_applications add column if not exists hourly_rate_cents int check (hourly_rate_cents > 0);

create policy app_owner_read on public.teacher_applications for select using (user_id = auth.uid() or public.is_admin());
create policy app_owner_insert on public.teacher_applications for insert with check (
  user_id = auth.uid() and review_status = 'draft' and reviewer_notes is null and reviewed_by is null
  and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'teacher'));
create policy app_owner_update on public.teacher_applications for update
  using (user_id = auth.uid()) with check (user_id = auth.uid());
-- Admins change applications ONLY through review_application() below.

create function public.guard_application() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.updated_at := now();
  if auth.uid() is null or public.is_admin() then return new; end if;
  if old.review_status not in ('draft','needs_information') then
    raise exception 'application is locked while under review or decided';
  end if;
  if new.review_status not in (old.review_status, 'submitted') then
    raise exception 'invalid status change';
  end if;
  if new.user_id <> old.user_id or new.reviewer_notes is distinct from old.reviewer_notes
     or new.reviewed_by is distinct from old.reviewed_by or new.reviewed_at is distinct from old.reviewed_at then
    raise exception 'review fields are admin-only';
  end if;
  if new.review_status = 'submitted' then
    if not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'identity')
       or not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'qualification') then
      raise exception 'identity and qualification documents are required';
    end if;
    new.submitted_at := now();
  end if;
  return new;
end $$;
create trigger trg_guard_application before update on public.teacher_applications
  for each row execute function public.guard_application();

-- ---------- credential documents (private) ----------
create policy docs_read on public.teacher_documents for select using (
  public.is_admin() or exists (select 1 from public.teacher_applications a where a.id = application_id and a.user_id = auth.uid()));
create policy docs_insert on public.teacher_documents for insert with check (
  storage_path like auth.uid()::text || '/%' and exists (
    select 1 from public.teacher_applications a where a.id = application_id and a.user_id = auth.uid()
      and a.review_status in ('draft','needs_information')));
create policy docs_delete on public.teacher_documents for delete using (
  exists (select 1 from public.teacher_applications a where a.id = application_id and a.user_id = auth.uid()
      and a.review_status in ('draft','needs_information')));

insert into storage.buckets (id, name, public) values ('credentials','credentials', false) on conflict (id) do nothing;
create policy cred_upload on storage.objects for insert to authenticated
  with check (bucket_id = 'credentials' and (storage.foldername(name))[1] = auth.uid()::text);
create policy cred_read on storage.objects for select to authenticated
  using (bucket_id = 'credentials' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));

-- ---------- public directory: approved + published only ----------
create policy directory_public on public.teacher_public_profiles for select to anon, authenticated
  using (published and public.is_approved_teacher(teacher_id));
revoke insert, update, delete on public.teacher_public_profiles from anon, authenticated;

-- ---------- admin decision (the ONLY way a teacher becomes public) ----------
create function public.review_application(p_application uuid, p_decision public.teacher_review_status, p_notes text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare a public.teacher_applications; n text;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('in_review','needs_information','approved','rejected') then raise exception 'invalid decision'; end if;
  select * into a from public.teacher_applications where id = p_application for update;
  if not found then raise exception 'application not found'; end if;
  if a.review_status = 'draft' then raise exception 'application not yet submitted'; end if;
  if p_decision in ('needs_information','rejected') and coalesce(trim(p_notes),'') = '' then
    raise exception 'a note is required for this decision';
  end if;

  update public.teacher_applications set review_status = p_decision, reviewer_notes = p_notes,
    reviewed_at = now(), reviewed_by = auth.uid() where id = a.id;

  if p_decision = 'approved' then
    select full_name into n from public.profiles where id = a.user_id;
    insert into public.teacher_public_profiles (teacher_id, display_name, bio, subjects, grades, formats, published)
    values (a.user_id, n, a.professional_bio, a.subjects, a.grades, a.teaching_formats, true)
    on conflict (teacher_id) do update set display_name = excluded.display_name, bio = excluded.bio,
      subjects = excluded.subjects, grades = excluded.grades, formats = excluded.formats,
      published = true, updated_at = now();
  else  -- any other decision (incl. revoking a prior approval) removes the listing
    update public.teacher_public_profiles set published = false, updated_at = now() where teacher_id = a.user_id;
  end if;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_application', 'teacher_application', a.id,
          jsonb_build_object('from', a.review_status, 'to', p_decision, 'notes', p_notes));
end $$;

-- ---------- bookings (parents and schools) ----------
create table public.bookings (
  id uuid primary key default gen_random_uuid(),
  requester_id uuid not null references public.profiles(id),
  teacher_id uuid not null references public.profiles(id),
  subject text not null, learner_grade text, learning_format text, message text,
  starts_at timestamptz not null, ends_at timestamptz not null check (ends_at > starts_at),
  status text not null default 'requested'
    check (status in ('requested','accepted','declined','cancelled','completed')),
  price_cents int check (price_cents > 0), currency text not null default 'ZAR',
  cancel_reason text, created_at timestamptz not null default now()
);
alter table public.bookings enable row level security;
create policy bk_read on public.bookings for select
  using (requester_id = auth.uid() or teacher_id = auth.uid() or public.is_admin());
create policy bk_insert on public.bookings for insert with check (
  requester_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('parent','school')));
create policy bk_update on public.bookings for update using (requester_id = auth.uid() or teacher_id = auth.uid());

-- (needs bookings table, so defined here)
create policy profiles_read on public.profiles for select
  using (id = auth.uid() or public.is_admin()
    or exists (select 1 from public.bookings b where (b.requester_id = profiles.id and b.teacher_id = auth.uid())));
create function public.guard_booking() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    if not public.is_approved_teacher(new.teacher_id) then raise exception 'teacher is not approved'; end if;
    if new.starts_at < now() then raise exception 'start time is in the past'; end if;
    new.status := 'requested'; new.price_cents := null; return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.requester_id <> old.requester_id or new.teacher_id <> old.teacher_id
     or new.starts_at <> old.starts_at or new.ends_at <> old.ends_at then
    raise exception 'booking details are fixed; cancel and rebook';
  end if;
  if new.status = old.status then return new; end if;
  if auth.uid() = old.teacher_id and old.status = 'requested' and new.status in ('accepted','declined') then
    if new.status = 'accepted' and new.price_cents is null then raise exception 'price required to accept'; end if;
  elsif auth.uid() = old.teacher_id and old.status = 'accepted' and new.status = 'completed' and now() >= old.ends_at then null;
  elsif old.status in ('requested','accepted') and new.status = 'cancelled' then null;
  else raise exception 'transition % -> % not allowed', old.status, new.status;
  end if;
  return new;
end $$;
create trigger trg_guard_booking before insert or update on public.bookings
  for each row execute function public.guard_booking();

-- ---------- payments & payouts (written by server/webhooks only) ----------
create table public.payouts (
  id uuid primary key default gen_random_uuid(),
  teacher_id uuid not null references public.profiles(id),
  amount_cents int not null check (amount_cents > 0), currency text not null default 'ZAR',
  status text not null default 'pending' check (status in ('pending','approved','paid','failed')),
  approved_by uuid references public.profiles(id), provider_ref text,
  created_at timestamptz not null default now(), paid_at timestamptz
);
create table public.payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id),
  payer_id uuid not null references public.profiles(id),
  amount_cents int not null check (amount_cents > 0),
  platform_fee_cents int not null default 0 check (platform_fee_cents >= 0),
  currency text not null default 'ZAR', provider text not null,
  provider_ref text unique, payout_id uuid references public.payouts(id),
  status text not null default 'pending' check (status in ('pending','paid','failed','refunded')),
  created_at timestamptz not null default now()
);
alter table public.payments enable row level security;
alter table public.payouts enable row level security;
create policy pay_read on public.payments for select using (
  payer_id = auth.uid() or public.is_admin()
  or exists (select 1 from public.bookings b where b.id = booking_id and b.teacher_id = auth.uid()));
create policy payout_read on public.payouts for select using (teacher_id = auth.uid() or public.is_admin());
revoke insert, update, delete on public.payments, public.payouts from anon, authenticated;

create function public.set_payout_status(p_payout uuid, p_status text, p_ref text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare p public.payouts;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_status not in ('approved','paid','failed') then raise exception 'invalid status'; end if;
  select * into p from public.payouts where id = p_payout for update;
  if not found then raise exception 'payout not found'; end if;
  if not public.is_approved_teacher(p.teacher_id) then raise exception 'teacher is not approved'; end if;
  if p_status = 'approved' and p.status <> 'pending' then raise exception 'only pending payouts can be approved'; end if;
  if p_status = 'paid' and p.status <> 'approved' then raise exception 'approve before paying'; end if;
  update public.payouts set status = p_status, provider_ref = coalesce(p_ref, provider_ref),
    approved_by = case when p_status = 'approved' then auth.uid() else approved_by end,
    paid_at = case when p_status = 'paid' then now() else paid_at end where id = p.id;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'payout_' || p_status, 'payout', p.id, jsonb_build_object('ref', p_ref));
end $$;

-- ---------- function permissions ----------
revoke execute on function public.review_application, public.set_payout_status from public, anon;
grant execute on function public.review_application, public.set_payout_status to authenticated;
