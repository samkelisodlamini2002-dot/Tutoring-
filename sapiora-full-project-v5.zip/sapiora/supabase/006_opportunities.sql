-- SAPIORA 006: teaching opportunities (Indeed-style job board). Run once, after 005.
-- Rules: posts are moderated before going live; ONLY admin-approved teachers can apply;
-- applicant contact details are shared with a poster only after they shortlist or accept.

create table public.job_posts (
  id uuid primary key default gen_random_uuid(),
  poster_id uuid not null references public.profiles(id),
  organisation text not null,
  title text not null check (char_length(title) between 5 and 120),
  description text not null check (char_length(description) between 20 and 5000),
  subjects text[] not null default '{}', phases text[] not null default '{}',
  format text not null check (format in ('online','in_person','either')),
  location text,
  job_type text not null check (job_type in ('tutoring','part_time','full_time','holiday_class','contract')),
  pay_text text, closes_on date,
  status text not null default 'pending_review' check (status in ('pending_review','open','rejected','closed')),
  reviewer_notes text, reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
create table public.job_applications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.job_posts(id) on delete cascade,
  teacher_id uuid not null references public.profiles(id),
  cover_note text check (char_length(cover_note) <= 3000),
  status text not null default 'submitted' check (status in ('submitted','shortlisted','declined','accepted','withdrawn')),
  created_at timestamptz not null default now(),
  unique (job_id, teacher_id)
);
create table public.saved_jobs (
  teacher_id uuid not null references public.profiles(id),
  job_id uuid not null references public.job_posts(id) on delete cascade,
  primary key (teacher_id, job_id)
);
alter table public.job_posts enable row level security;
alter table public.job_applications enable row level security;
alter table public.saved_jobs enable row level security;

create function public.is_job_poster(j uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.job_posts where id = j and poster_id = auth.uid());
$$;
create function public.can_see_applicant(t uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.job_applications a join public.job_posts j on j.id = a.job_id
    where a.teacher_id = t and j.poster_id = auth.uid() and a.status in ('shortlisted','accepted'));
$$;

-- job posts
create policy jobs_public_read on public.job_posts for select to anon, authenticated
  using (status = 'open' and (closes_on is null or closes_on >= current_date));
create policy jobs_owner_read on public.job_posts for select using (poster_id = auth.uid() or public.is_admin());
create policy jobs_insert on public.job_posts for insert with check (
  poster_id = auth.uid() and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('parent','school')));
create policy jobs_update on public.job_posts for update using (poster_id = auth.uid()) with check (poster_id = auth.uid());

create function public.guard_job() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    new.status := 'pending_review'; new.reviewer_notes := null; new.reviewed_at := null; return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.reviewer_notes is distinct from old.reviewer_notes or new.reviewed_at is distinct from old.reviewed_at
     or new.poster_id <> old.poster_id then raise exception 'review fields are admin-only'; end if;
  if new.status is distinct from old.status then
    if not (old.status in ('open','pending_review') and new.status = 'closed') then raise exception 'invalid status change'; end if;
  elsif row(new.title, new.description, new.organisation, new.subjects, new.phases, new.format, new.location, new.job_type, new.pay_text)
        is distinct from row(old.title, old.description, old.organisation, old.subjects, old.phases, old.format, old.location, old.job_type, old.pay_text) then
    if old.status = 'closed' then raise exception 'closed posts cannot be edited'; end if;
    new.status := 'pending_review';  -- edits to a live post are re-reviewed
  end if;
  return new;
end $$;
create trigger trg_guard_job before insert or update on public.job_posts for each row execute function public.guard_job();

create function public.review_job(p_job uuid, p_decision text, p_notes text default null) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('open','rejected') then raise exception 'invalid decision'; end if;
  if p_decision = 'rejected' and coalesce(trim(p_notes), '') = '' then raise exception 'a reason is required'; end if;
  update public.job_posts set status = p_decision, reviewer_notes = p_notes, reviewed_at = now()
   where id = p_job and status in ('pending_review','open','rejected');
  if not found then raise exception 'post not found or closed'; end if;
  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_job', 'job_post', p_job, jsonb_build_object('decision', p_decision, 'notes', p_notes));
end $$;
revoke execute on function public.review_job from public, anon;
grant execute on function public.review_job to authenticated;

-- applications
create policy apps_read on public.job_applications for select
  using (teacher_id = auth.uid() or public.is_admin() or public.is_job_poster(job_id));
create policy apps_insert on public.job_applications for insert with check (teacher_id = auth.uid());
create policy apps_update on public.job_applications for update
  using (teacher_id = auth.uid() or public.is_job_poster(job_id));

create function public.guard_application_job() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  if tg_op = 'INSERT' then
    if not public.is_approved_teacher(new.teacher_id) then raise exception 'only approved teachers can apply'; end if;
    if not exists (select 1 from public.job_posts where id = new.job_id and status = 'open' and (closes_on is null or closes_on >= current_date)) then
      raise exception 'this opportunity is not open'; end if;
    new.status := 'submitted'; return new;
  end if;
  if auth.uid() is null or public.is_admin() then return new; end if;
  if new.job_id <> old.job_id or new.teacher_id <> old.teacher_id or new.cover_note is distinct from old.cover_note then
    raise exception 'application details cannot be changed'; end if;
  if new.status = old.status then return new; end if;
  if auth.uid() = old.teacher_id then
    if not (old.status in ('submitted','shortlisted') and new.status = 'withdrawn') then raise exception 'invalid status change'; end if;
  elsif public.is_job_poster(old.job_id) then
    if not ((old.status = 'submitted' and new.status in ('shortlisted','declined','accepted'))
         or (old.status = 'shortlisted' and new.status in ('accepted','declined'))) then raise exception 'invalid status change'; end if;
  else raise exception 'not allowed'; end if;
  return new;
end $$;
create trigger trg_guard_application_job before insert or update on public.job_applications
  for each row execute function public.guard_application_job();

create policy saved_own on public.saved_jobs for all using (teacher_id = auth.uid()) with check (teacher_id = auth.uid());

-- a poster may read an applicant's contact details only after shortlisting or accepting them
create policy profiles_read_applicant on public.profiles for select using (public.can_see_applicant(id));
