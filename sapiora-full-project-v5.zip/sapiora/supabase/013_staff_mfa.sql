-- SAPIORA 013: staff must sign in with a second factor (authenticator app).
-- RUN THIS LAST. Only after every admin and every verifier has signed in to their
-- portal and set up their authenticator app. Anyone who has not will lose staff
-- access until they do (they can still sign in to the portal and enrol).
-- To undo: re-run the original is_admin / is_verifier definitions from 002 and 011.

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin')
     and coalesce(auth.jwt() ->> 'aal', '') = 'aal2';
$$;

create or replace function public.is_verifier() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.verifiers where user_id = auth.uid())
     and coalesce(auth.jwt() ->> 'aal', '') = 'aal2';
$$;
