-- SAPIORA 010: teachers must accept the Teacher Services Agreement before submitting. Run once, after 009.
alter table public.teacher_applications
  add column if not exists terms_version text check (char_length(terms_version) <= 40),
  add column if not exists terms_accepted_at timestamptz;

create function public.guard_terms() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  -- the acceptance time is always set by the server, never by the browser
  if new.terms_version is distinct from old.terms_version then
    new.terms_accepted_at := case when new.terms_version is null then null else now() end;
  else
    new.terms_accepted_at := old.terms_accepted_at;
  end if;
  if new.review_status = 'submitted' and old.review_status is distinct from 'submitted' and new.terms_version is null
     and auth.uid() is not null and not public.is_admin() then
    raise exception 'You must accept the Teacher Services Agreement before submitting.';
  end if;
  return new;
end $$;
create trigger trg_guard_terms before update on public.teacher_applications for each row execute function public.guard_terms();
