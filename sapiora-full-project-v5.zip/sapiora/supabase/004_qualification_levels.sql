-- SAPIORA 004: teaching qualification levels (run once, after 003)
alter table public.teacher_applications add column if not exists qualification_levels text[] not null default '{}';
alter table public.teacher_applications add constraint app_levels_valid check (
  qualification_levels <@ array['higher_certificate','diploma','bed','pgce','ace','advanced_diploma','honours','masters','doctorate','other']::text[]);
alter table public.teacher_public_profiles add column if not exists qualification_levels text[] not null default '{}';

-- Submission now requires at least one qualification level
create or replace function public.guard_application() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  new.updated_at := now();
  if auth.uid() is null or public.is_admin() then return new; end if;
  if old.review_status not in ('draft','needs_information') then
    raise exception 'application is locked while under review or decided';
  end if;
  if new.review_status not in (old.review_status, 'submitted') then
    raise exception 'invalid status change';
  end if;
  if new.user_id <> old.user_id or new.reviewer_notes is distinct from old.reviewer_notes
     or new.reviewed_by is distinct from old.reviewed_by or new.reviewed_at is distinct from old.reviewed_at then
    raise exception 'review fields are admin-only';
  end if;
  if new.review_status = 'submitted' then
    if coalesce(array_length(new.qualification_levels, 1), 0) = 0 then raise exception 'select at least one teaching qualification'; end if;
    if not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'identity')
       or not exists (select 1 from public.teacher_documents where application_id = new.id and document_type = 'qualification') then
      raise exception 'identity and qualification documents are required';
    end if;
    new.submitted_at := now();
  end if;
  return new;
end $$;

-- Approval now publishes the declared qualification levels
create or replace function public.review_application(p_application uuid, p_decision public.teacher_review_status, p_notes text default null)
returns void language plpgsql security definer set search_path = '' as $$
declare a public.teacher_applications; n text;
begin
  if not public.is_admin() then raise exception 'admin only' using errcode = '42501'; end if;
  if p_decision not in ('in_review','needs_information','approved','rejected') then raise exception 'invalid decision'; end if;
  select * into a from public.teacher_applications where id = p_application for update;
  if not found then raise exception 'application not found'; end if;
  if a.review_status = 'draft' then raise exception 'application not yet submitted'; end if;
  if p_decision in ('needs_information','rejected') and coalesce(trim(p_notes),'') = '' then
    raise exception 'a note is required for this decision';
  end if;

  update public.teacher_applications set review_status = p_decision, reviewer_notes = p_notes,
    reviewed_at = now(), reviewed_by = auth.uid() where id = a.id;

  if p_decision = 'approved' then
    select full_name into n from public.profiles where id = a.user_id;
    insert into public.teacher_public_profiles (teacher_id, display_name, bio, subjects, grades, formats, qualification_levels, published)
    values (a.user_id, n, a.professional_bio, a.subjects, a.grades, a.teaching_formats, a.qualification_levels, true)
    on conflict (teacher_id) do update set display_name = excluded.display_name, bio = excluded.bio,
      subjects = excluded.subjects, grades = excluded.grades, formats = excluded.formats,
      qualification_levels = excluded.qualification_levels,
      published = true, updated_at = now();
  else  -- any other decision (incl. revoking a prior approval) removes the listing
    update public.teacher_public_profiles set published = false, updated_at = now() where teacher_id = a.user_id;
  end if;

  insert into public.audit_log (actor_id, action, entity, entity_id, details)
  values (auth.uid(), 'review_application', 'teacher_application', a.id,
          jsonb_build_object('from', a.review_status, 'to', p_decision, 'notes', p_notes));
end $$;

revoke execute on function public.review_application from public, anon;
grant execute on function public.review_application to authenticated;
