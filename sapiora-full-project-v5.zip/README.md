# SAPIORA: three sites, one Supabase project

| Folder | Who uses it | Deploy as |
|---|---|---|
| `sapiora/` | Parents, schools, teachers (public) | your existing project |
| `sapiora-admin/` | Admin only | a new, separate project |
| `sapiora-verify/` | Verification team only | a new, separate project |

All three use the same Supabase project (same URL and publishable key in `config.js`).
Access is still enforced by Supabase (row-level security and the `is_admin()` / `is_verifier()`
functions). The separate sites keep staff code off the public site and add a second sign-in step.
Never put the `service_role` key in any of these folders.

## Rollout, in this order
1. Deploy `sapiora-admin/` and `sapiora-verify/` as two new Cloudflare projects (build command empty, output directory `/`).
2. Supabase: Authentication, URL Configuration, Redirect URLs. Add both new site addresses (password reset links need them).
3. Supabase: Authentication, Multi-Factor. Make sure TOTP (authenticator app) is enabled.
4. Put the two addresses in `sapiora/config.js` (`ADMIN_URL`, `VERIFY_URL`) and redeploy the public site. Staff who open it are pointed to their portal.
5. Each admin and verifier opens their portal, signs in, and scans the QR code with an authenticator app.
6. Once everyone has done step 5, run `sapiora/supabase/013_staff_mfa.sql` in the SQL editor. From then on the database itself refuses staff actions without the second step.

## Verification levels (migration 014)
Run `sapiora/supabase/014_verification_checks.sql` once (after 011 and 012), then redeploy all three sites.
- Verifiers and admins tick four checks on each teacher: Identity, Qualification, SACE registration, Police clearance (needs a valid-until date).
- The public directory, booking page and teacher dashboard show only checks that are ticked and in date. Levels: Approved, ID and qualification verified, Fully vetted (all four).
- Teachers can upload a police clearance certificate, including after they are approved.
- A verifier can tick checks only for applications they can see (submitted, in review, or ones they decided). Admins can tick any. Nobody can tick their own.
- Every tick or removal is written to the audit log.
- Optional: the commented backfill at the end of 014 marks identity and qualification as verified for teachers approved before this feature.

## Adding staff
- Verifier: they sign up on the public site first, then an admin adds their email in the admin portal, Verification page.
- Admin: unchanged. Sign up, confirm email, then run `supabase/make-admin.sql`.

## Lost phone
Supabase dashboard, Authentication, Users, open the person, remove their MFA factor. They enrol again at next sign-in.

## Notes
- `staff-common.js` and `verify-view.js` are the same files in both portals. If you edit one, copy it to the other.
- Each portal folder is self-contained, so each has its own copy of `config.js`. Keep the Supabase URL and key identical.
- The public `platform.js` no longer contains any admin or verification code.
