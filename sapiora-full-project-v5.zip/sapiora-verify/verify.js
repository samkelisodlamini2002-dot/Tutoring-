// SAPIORA verification portal: only what the verification team needs.
const STAFF_KIND = "verifier";

portal.click.review = async (b, id) => {
  if (b.dataset.d === "approved" && !coreVerified(APPTEACHER[id]) && !confirm("Identity and qualification are not both ticked as verified yet. Approve anyway?")) return;
  const d = b.dataset.d, n = d === "approved" ? prompt("Optional note:") : prompt("Note for the teacher (required):");
  if (n === null || (d !== "approved" && !n.trim())) return;
  must(await sb.rpc("review_application", { p_application: id, p_decision: d, p_notes: n || null })); refresh();
};
portal.submit.docreq = async (f, v) => {
  const types = new FormData(f).getAll("types");
  if (!types.length) throw new Error("Tick at least one document to request.");
  must(await sb.rpc("review_application", { p_application: f.dataset.id, p_decision: "needs_information", p_notes: "Documents requested: " + types.join(", ") + ". " + v.msg })); refresh();
};

startPortal({
  title: "Verification portal",
  allowed: () => !!me && isVerifier,
  nav: [["Verification queue", "#/"]],
  routes: { "": viewVerify }
});
