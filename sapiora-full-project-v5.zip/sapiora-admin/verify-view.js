// SAPIORA verification view and checks: shared by the admin and verification portals (identical copy in each).
const CHECKS = [["identity", "Identity", false], ["qualification", "Qualification", false], ["sace", "SACE registration", "optional"], ["police_clearance", "Police clearance", "required"]];
const todayISO = () => new Date().toISOString().slice(0, 10);
const checkLive = c => !!c && (!c.expires_on || c.expires_on >= todayISO());
const groupChecks = rows => (rows || []).reduce((m, c) => { (m[c.teacher_id] = m[c.teacher_id] || {})[c.check_type] = c; return m; }, {});
const tierOf = ck => { const ok = k => checkLive(ck && ck[k]); return ok("identity") && ok("qualification") ? (ok("sace") && ok("police_clearance") ? "full" : "core") : "basic"; };
const TIER = { full: ["Fully vetted", "ok"], core: ["ID and qualification verified", "ok"], basic: ["Approved", ""] };
const day = d => new Date(d).toLocaleDateString("en-ZA", { dateStyle: "medium" });
let CHECKMAP = {}, APPTEACHER = {};
const coreVerified = tid => { const ck = CHECKMAP[tid] || {}; return checkLive(ck.identity) && checkLive(ck.qualification); };

function checksPanel(tid) {
  const ck = CHECKMAP[tid] || {}, [tl, tc] = TIER[tierOf(ck)];
  return `<div class="card" style="margin:10px 0"><div class="row"><h3>Verification checks</h3>${tag(tl, tc)}</div>
  <small>Tick a check only after you have seen the evidence. Each tick shows as a badge on the teacher's public profile. Police clearance needs a valid-until date and disappears when it expires.</small>
  ${CHECKS.map(([k, l, exp]) => { const c = ck[k];
    const state = !c ? '<span class="muted">Not verified</span>' : checkLive(c) ? tag("Verified " + day(c.verified_at) + (c.expires_on ? ", valid until " + day(c.expires_on) : ""), "ok") : tag("Expired " + day(c.expires_on), "warn");
    return `<form class="checkrow" data-form="check" data-id="${tid}" data-type="${k}"><span><b>${l}</b><br>${state}</span>
      ${exp ? `<label style="margin:0">Valid until${exp === "optional" ? " (optional)" : ""}<input name="expires" type="date" ${exp === "required" ? "required" : ""} value="${esc(c && c.expires_on || "")}"></label>` : ""}
      <span><button class="btn btn-outline btn-small">${c ? "Update" : "Mark verified"}</button>${c ? ` <button type="button" class="btn btn-danger btn-small" data-act="uncheck" data-id="${tid}" data-type="${k}">Remove</button>` : ""}</span><p class="err" role="alert" style="width:100%"></p></form>`; }).join("")}</div>`;
}
portal.submit.check = async (f, v) => { must(await sb.rpc("set_teacher_check", { p_teacher: f.dataset.id, p_type: f.dataset.type, p_verified: true, p_expires: v.expires || null })); refresh(); };
portal.click.uncheck = async (b, id) => { if (confirm("Remove this check? The badge disappears from the teacher's public profile.")) { must(await sb.rpc("set_teacher_check", { p_teacher: id, p_type: b.dataset.type, p_verified: false, p_expires: null })); refresh(); } };

// ===== Verification team page =====
async function appCard(a, actions) {
  APPTEACHER[a.id] = a.user_id;
  const docs = await Promise.all((a.teacher_documents || []).map(async d => `<a href="${await signed("credentials", d.storage_path)}" target="_blank" rel="noopener">${esc(d.document_type)}</a>`));
  return `<div class="card"><div class="row"><h3>${esc(a.p?.full_name)}</h3>${tag(label(a.review_status), statusClass(a.review_status))}</div>
  <small>${esc(a.p?.email)} · SACE: ${esc(a.sace_number || "not given")} · Rate: ${a.hourly_rate_cents ? rand(a.hourly_rate_cents) + " per hour" : "not set"}</small>
  <p>${esc(a.professional_bio)}</p><p><b>Declared qualifications:</b> ${esc(qualSummary(a.qualification_levels, a.qualification_programmes) || "none")}</p>
  <p><b>Details:</b> ${esc(a.qualification_summary)}</p><p><b>Subjects:</b> ${esc((a.subjects || []).join(", "))} · <b>Grades:</b> ${esc((a.grades || []).join(", "))}</p>
  <p><b>Agreement:</b> ${a.terms_accepted_at ? "accepted " + when(a.terms_accepted_at) + " (version " + esc(a.terms_version) + ")" : "not accepted"}</p>
  <p><b>Documents:</b> ${docs.join(" · ") || "none uploaded"}</p>
  ${a.reviewer_notes ? `<p class="muted">Note: ${esc(a.reviewer_notes)}</p>` : ""}
  ${a.vb?.full_name ? `<p class="muted">Verified by ${esc(a.vb.full_name)} on ${when(a.verified_at)}</p>` : ""}
  ${a.user_id !== me.id ? checksPanel(a.user_id) : ""}
  ${actions ? `<div class="actions">${actions}</div>` : ""}</div>`;
}

async function viewVerify() {
  const admin = me.role === "admin" && STAFF_KIND === "admin";
  const sel = "*, p:profiles!user_id(full_name,email), vb:profiles!verified_by(full_name), teacher_documents(*)";
  const none = { data: [], error: null };
  const [queue, mine, team, vers, chk] = await Promise.all([
    sb.from("teacher_applications").select(sel).in("review_status", ["submitted", "in_review"]).order("submitted_at"),
    sb.from("teacher_applications").select(sel).eq("reviewed_by", me.id).in("review_status", ["approved", "rejected", "needs_information"]).order("reviewed_at", { ascending: false }).limit(50),
    admin ? sb.from("teacher_applications").select(sel).not("verified_by", "is", null).order("verified_at", { ascending: false }).limit(100) : none,
    admin ? sb.from("verifiers").select("user_id, p:profiles!user_id(full_name,email)") : none,
    sb.from("teacher_checks").select("teacher_id,check_type,verified_at,expires_on")]).then(r => r.map(must));
  CHECKMAP = groupChecks(chk);
  const decide = id => `<button class="btn btn-primary btn-small" data-act="review" data-d="approved" data-id="${id}">Approve and list</button>
    <button class="btn btn-outline btn-small" data-act="review" data-d="needs_information" data-id="${id}">Request information</button>
    <button class="btn btn-danger btn-small" data-act="review" data-d="rejected" data-id="${id}">Reject</button>
    <form data-form="docreq" data-id="${id}" style="width:100%;margin-top:10px"><fieldset class="qual"><legend>Request documents</legend>
    ${["Identity document", "Teaching qualification certificate", "SACE registration proof", "Police clearance certificate", "Other supporting document"].map(t => `<label><input type="checkbox" name="types" value="${t}"> ${t}</label>`).join("")}</fieldset>
    <label>Message to the teacher<textarea name="msg" rows="2" required></textarea></label><button class="btn btn-outline btn-small">Send request</button><p class="err" role="alert"></p></form>`;
  let h = `<h1>Verification</h1><p class="lede">Check each teacher's documents against what they declared. You can only see applications that have been submitted for review. Approving publishes the teacher to the public directory.</p>
  <div class="card"><h3>Before you approve</h3><small>Identity document matches the name. Qualification is genuine and matches the declared level and programme. SACE registration is valid where it applies. The agreement has been accepted. Keep all documents confidential. Tick the verification checks on each teacher as you confirm them; they show as badges in the public directory.</small></div>
  <h2>Waiting for verification (${queue.length})</h2>`;
  for (const a of queue) h += await appCard(a, a.user_id === me.id ? "" : decide(a.id));
  if (!queue.length) h += `<p class="muted">Nothing waiting.</p>`;
  h += `<h2>${admin ? "My decisions" : "Decisions I made"}</h2>`;
  for (const a of mine) h += await appCard(a, "");
  if (!mine.length) h += `<p class="muted">No decisions yet.</p>`;
  if (admin) {
    h += `<h2>Approved by the verification team</h2><p class="muted">You can reject any of these at any time. The teacher is removed from the directory immediately.</p>`;
    for (const a of team) h += await appCard(a, a.review_status === "approved" ? `<button class="btn btn-danger btn-small" data-act="review" data-d="rejected" data-id="${a.id}">Reject this teacher</button>` : "");
    if (!team.length) h += `<p class="muted">Nothing verified by the team yet.</p>`;
    h += `<h2>Verification team</h2>` + (vers.map(v => `<div class="card row"><span>${esc(v.p?.full_name)} · ${esc(v.p?.email)}</span><button class="btn btn-outline btn-small" data-act="rmverifier" data-id="${v.user_id}">Remove</button></div>`).join("") || `<p class="muted">No verifiers added yet.</p>`);
    h += `<form class="card" data-form="addverifier"><label>Add a verifier by email (they must have signed up first)<input name="email" type="email" required></label><button class="btn btn-primary btn-small">Add verifier</button><p class="err" role="alert"></p></form>`;
  }
  app.innerHTML = h + `<p class="err" role="alert"></p>`;
}


