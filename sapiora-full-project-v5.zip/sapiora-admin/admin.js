// SAPIORA admin portal: applications, payments, payouts, opportunities, fees and the verification team.
const STAFF_KIND = "admin";

// ===== Admin =====
async function adminHTML() {
  const [apps, pays, paid, payouts] = await Promise.all([
    sb.from("teacher_applications").select("*, p:profiles!user_id(full_name,email), teacher_documents(*)").in("review_status", ["submitted", "in_review"]).order("submitted_at"),
    sb.from("payments").select("*, p:profiles!payer_id(full_name)").eq("status", "pending").not("proof_path", "is", null),
    sb.from("payments").select("amount_cents,platform_fee_cents,payout_id,bookings(teacher_id,status)").eq("status", "paid").is("payout_id", null),
    sb.from("payouts").select("*").order("created_at", { ascending: false }).limit(30)]).then(r => r.map(must));
  const names = Object.fromEntries(must(await sb.from("profiles").select("id,full_name").eq("role", "teacher")).map(p => [p.id, p.full_name]));
  let h = `<h2>Teacher applications awaiting review</h2>`;
  for (const a of apps) {
    const docs = await Promise.all((a.teacher_documents || []).map(async d => `<a href="${await signed("credentials", d.storage_path)}" target="_blank" rel="noopener">${esc(d.document_type)}</a>`));
    h += `<div class="card"><div class="row"><h3>${esc(a.p?.full_name)}</h3>${tag(label(a.review_status), statusClass(a.review_status))}</div><small>${esc(a.p?.email)} · SACE: ${esc(a.sace_number || "not given")}</small>
    <p>${esc(a.professional_bio)}</p><p><b>Agreement:</b> ${a.terms_accepted_at ? "accepted " + when(a.terms_accepted_at) + " (version " + esc(a.terms_version) + ")" : "not accepted"}</p><p><b>Declared qualifications:</b> ${esc(qualSummary(a.qualification_levels, a.qualification_programmes) || "none")}</p><p><b>Details:</b> ${esc(a.qualification_summary)}</p><p><b>Documents:</b> ${docs.join(" · ") || "none"}</p>
    <div class="actions"><button class="btn btn-primary btn-small" data-act="review" data-d="approved" data-id="${a.id}">Approve & list</button>
    <button class="btn btn-outline btn-small" data-act="review" data-d="needs_information" data-id="${a.id}">Request information</button>
    <button class="btn btn-danger btn-small" data-act="review" data-d="rejected" data-id="${a.id}">Reject</button></div></div>`;
  }
  h += apps.length ? "" : `<p class="muted">No applications waiting.</p>`;
  h += `<h2>EFT payments to confirm</h2>`;
  for (const p of pays) h += `<div class="card row"><span>${esc(p.p?.full_name)} · ${rand(p.amount_cents)} · ${esc(p.provider_ref)}</span><span><a href="${await signed("eft-proofs", p.proof_path)}" target="_blank" rel="noopener">View proof</a> <button class="btn btn-primary btn-small" data-act="confirm" data-id="${p.id}">Confirm received</button></span></div>`;
  h += pays.length ? "" : `<p class="muted">No payments awaiting confirmation.</p>`;
  const owed = {};
  paid.filter(p => p.bookings?.status === "completed").forEach(p => owed[p.bookings.teacher_id] = (owed[p.bookings.teacher_id] || 0) + p.amount_cents - p.platform_fee_cents);
  h += `<h2>Owed to teachers</h2>` + (Object.entries(owed).map(([t, c]) => `<div class="card row"><span>${esc(names[t] || t)} · ${rand(c)}</span><button class="btn btn-primary btn-small" data-act="payout" data-id="${t}">Create payout</button></div>`).join("") || `<p class="muted">Nothing owed.</p>`);
  h += `<h2>Payouts</h2>` + (payouts.map(p => `<div class="card row"><span>${esc(names[p.teacher_id] || "")} · ${rand(p.amount_cents)} ${tag(p.status, statusClass(p.status))}</span><span>
    ${p.status === "pending" ? `<button class="btn btn-outline btn-small" data-act="setpayout" data-s="approved" data-id="${p.id}">Approve</button>` : ""}
    ${p.status === "approved" ? `<button class="btn btn-primary btn-small" data-act="setpayout" data-s="paid" data-id="${p.id}">Mark paid (EFT sent)</button>` : ""}</span></div>`).join("") || `<p class="muted">No payouts yet.</p>`);
  return h;
}


async function adminJobsHTML() {
  const pend = must(await sb.from("job_posts").select("*").eq("status", "pending_review").order("created_at"));
  return `<h2>Teaching opportunities awaiting review</h2>` + (pend.map(p => `<div class="card"><h3>${esc(p.title)}</h3><small>${jobMeta(p)}</small>
    <p style="white-space:pre-line">${esc(p.description)}</p><div>${jobTags(p)}</div><div class="actions"><button class="btn btn-primary btn-small" data-act="reviewjob" data-d="open" data-id="${p.id}">Approve & publish</button>
    <button class="btn btn-danger btn-small" data-act="reviewjob" data-d="rejected" data-id="${p.id}">Reject</button></div></div>`).join("") || `<p class="muted">No opportunities waiting.</p>`);
}

async function adminSettingsHTML() {
  const [st, pays, jobs] = await Promise.all([
    sb.from("platform_settings").select("*"),
    sb.from("payments").select("platform_fee_cents").eq("status", "paid"),
    sb.from("job_posts").select("id,title,organisation,status,fee_cents,fee_paid_at,fee_proof_path,fee_reference").or("status.eq.awaiting_payment,fee_paid_at.not.is.null")]).then(r => r.map(must));
  const S = Object.fromEntries(st.map(s => [s.key, Number(s.value)]));
  const lessonFees = pays.reduce((n, p) => n + p.platform_fee_cents, 0), postFees = jobs.filter(x => x.fee_paid_at).reduce((n, x) => n + x.fee_cents, 0);
  let h = `<h2>Revenue and fees</h2><div class="card"><div class="row"><span>Lesson fees collected</span><b>${rand(lessonFees)}</b></div>
  <div class="row"><span>Posting fees collected</span><b>${rand(postFees)}</b></div><div class="row"><span><b>Total</b></span><b>${rand(lessonFees + postFees)}</b></div></div>
  <form class="card" data-form="settings"><h3>Fee settings</h3><div class="grid2"><label>Fee on each paid lesson (%)<input name="pct" type="number" min="0" max="50" step="0.5" value="${S.fee_percent}" required></label>
  <label>Fee to post an opportunity (Rand, 0 = free)<input name="fee" type="number" min="0" step="1" value="${S.job_post_fee_cents / 100}" required></label></div>
  <label><input type="checkbox" name="schools" ${S.job_fee_schools_only ? "checked" : ""}> Charge the posting fee to schools only (parents post free)</label>
  <button class="btn btn-primary">Save settings</button><p class="err" role="alert"></p><small>Changes apply to new lessons and newly approved posts.</small></form><h2>Posting fees to confirm</h2>`;
  const due = jobs.filter(x => x.status === "awaiting_payment" && x.fee_proof_path);
  for (const x of due) h += `<div class="card row"><span>${esc(x.organisation)} · ${esc(x.title)} · ${rand(x.fee_cents)} · ${esc(x.fee_reference)}</span><span><a href="${await signed("eft-proofs", x.fee_proof_path)}" target="_blank" rel="noopener">View proof</a> <button class="btn btn-primary btn-small" data-act="confirmfee" data-id="${x.id}">Confirm received</button></span></div>`;
  return h + (due.length ? "" : `<p class="muted">No posting fees awaiting confirmation.</p>`);
}


async function viewDashboard() {
  app.innerHTML = `<h1>Admin portal</h1><p class="lede">Signed in as ${esc(me.full_name)}.</p><div id="acct"></div><p class="err" role="alert"></p>`;
  document.getElementById("acct").innerHTML = await adminHTML() + await adminJobsHTML() + await adminSettingsHTML();
}

portal.click.review = async (b, id) => {
  if (b.dataset.d === "approved" && !coreVerified(APPTEACHER[id]) && !confirm("Identity and qualification are not both ticked as verified yet. Approve anyway?")) return;
  const d = b.dataset.d, n = d === "approved" ? prompt("Optional note:") : prompt("Note for the teacher (required):");
  if (n === null || (d !== "approved" && !n.trim())) return;
  must(await sb.rpc("review_application", { p_application: id, p_decision: d, p_notes: n || null })); refresh();
};
portal.click.reviewjob = async (b, id) => {
  const d = b.dataset.d, n = prompt(d === "open" ? "Optional note:" : "Reason for rejecting (required):");
  if (n === null || (d === "rejected" && !n.trim())) return;
  must(await sb.rpc("review_job", { p_job: id, p_decision: d, p_notes: n || null })); refresh();
};
portal.click.confirm = async (b, id) => { must(await sb.rpc("confirm_eft_payment", { p_payment: id })); refresh(); };
portal.click.confirmfee = async (b, id) => { must(await sb.rpc("confirm_job_fee", { p_job: id })); refresh(); };
portal.click.payout = async (b, id) => { must(await sb.rpc("create_payout", { p_teacher: id })); refresh(); };
portal.click.setpayout = async (b, id) => { must(await sb.rpc("set_payout_status", { p_payout: id, p_status: b.dataset.s, p_ref: null })); refresh(); };
portal.click.rmverifier = async (b, id) => { if (confirm("Remove this verifier?")) { must(await sb.rpc("remove_verifier", { p_user: id })); refresh(); } };

portal.submit.docreq = async (f, v) => {
  const types = new FormData(f).getAll("types");
  if (!types.length) throw new Error("Tick at least one document to request.");
  must(await sb.rpc("review_application", { p_application: f.dataset.id, p_decision: "needs_information", p_notes: "Documents requested: " + types.join(", ") + ". " + v.msg })); refresh();
};
portal.submit.addverifier = async (f, v) => { must(await sb.rpc("add_verifier", { p_email: v.email })); refresh(); };
portal.submit.settings = async (f, v) => {
  must(await sb.rpc("set_setting", { p_key: "fee_percent", p_value: Number(v.pct) }));
  must(await sb.rpc("set_setting", { p_key: "job_post_fee_cents", p_value: Math.round(Number(v.fee) * 100) }));
  must(await sb.rpc("set_setting", { p_key: "job_fee_schools_only", p_value: v.schools ? 1 : 0 })); refresh();
};

startPortal({
  title: "Admin portal",
  allowed: () => !!me && me.role === "admin",
  nav: [["Dashboard", "#/"], ["Verification", "#/verify"]],
  routes: { "": viewDashboard, verify: viewVerify }
});
