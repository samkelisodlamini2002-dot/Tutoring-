// Shared qualification picker: tick a level, then choose the specific programme(s).
(function () {
  const C = window.SAPIORA;
  const esc = s => String(s).replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch]));
  const lvl = code => (C.LEVELS.find(l => l[0] === code) || [code, code])[1];
  const prog = v => { const [l, k] = v.split(":"); return ((C.PROGRAMMES[l] || []).find(p => p[0] === k) || [k, k])[1]; };

  window.renderQualPicker = function (el, levels = [], progs = []) {
    el.classList.add("qpick");
    el.innerHTML = C.LEVELS.map(([c, l]) => {
      const list = C.PROGRAMMES[c] || [], on = levels.includes(c);
      return `<div class="qlevel"><label><input type="checkbox" name="levels" value="${c}" ${on ? "checked" : ""}> ${esc(l)}</label>` +
        (list.length ? `<div class="qsub" data-for="${c}" ${on ? "" : "hidden"}><p>Which programme(s)?</p>` +
          list.map(([k, t]) => `<label><input type="checkbox" name="progs" value="${c}:${k}" ${progs.includes(c + ":" + k) ? "checked" : ""}> ${esc(t)}</label>`).join("") + "</div>" : "") + "</div>";
    }).join("");
    el.onchange = e => {
      if (e.target.name !== "levels") return;
      const sub = el.querySelector(`.qsub[data-for="${e.target.value}"]`);
      if (!sub) return;
      sub.hidden = !e.target.checked;
      if (!e.target.checked) sub.querySelectorAll("input").forEach(i => { i.checked = false; });
    };
  };

  window.readQuals = function (form) {
    const fd = new FormData(form), levels = fd.getAll("levels");
    const progs = fd.getAll("progs").filter(p => levels.includes(p.split(":")[0]));
    let error = null;
    if (!levels.length) error = "Select at least one teaching qualification.";
    else {
      const miss = levels.find(l => (C.PROGRAMMES[l] || []).length && !progs.some(p => p.startsWith(l + ":")));
      if (miss) error = `Choose at least one programme under "${lvl(miss)}".`;
    }
    return { levels, progs, error };
  };

  window.qualSummary = (levels = [], progs = []) => levels.map(l => {
    const ps = progs.filter(p => p.startsWith(l + ":")).map(prog);
    return lvl(l) + (ps.length ? " (" + ps.join(", ") + ")" : "");
  }).join("; ");
})();
