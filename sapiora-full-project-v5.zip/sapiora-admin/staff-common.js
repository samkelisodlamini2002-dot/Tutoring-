// SAPIORA staff portals: code shared by the admin and verification portals.
// Handles staff sign-in, the staff check, and the required two-step (authenticator app) sign-in.
// Both portals ship an identical copy of this file. Keep them in sync.
const { SUPABASE_URL, SUPABASE_ANON_KEY } = window.SAPIORA;
const sb = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
const app = document.getElementById("app");
let me = null, isVerifier = false;
const FORMATS = { online: "Online", in_person: "In person", either: "Online or in person" };
const JOB_TYPES = { tutoring: "Tutoring", part_time: "Part-time", full_time: "Full-time", holiday_class: "Holiday classes", contract: "Contract" };
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const rand = c => "R" + (c / 100).toLocaleString("en-ZA", { minimumFractionDigits: 2 });
const when = d => new Date(d).toLocaleString("en-ZA", { dateStyle: "medium", timeStyle: "short" });
const tag = (t, c = "") => `<span class="tag ${c}">${esc(t)}</span>`;
const statusClass = s => ({ approved: "ok", accepted: "ok", paid: "ok", completed: "ok", rejected: "bad", declined: "bad", cancelled: "bad", failed: "bad", open: "ok", shortlisted: "ok", pending_review: "warn", submitted: "warn", closed: "bad", withdrawn: "bad", awaiting_payment: "warn", needs_information: "warn", pending: "warn", requested: "warn" }[s] || "");
const label = s => String(s).replace(/_/g, " ");
const fail = e => { const el = document.activeElement?.closest?.("form")?.querySelector(".err") || document.querySelector(".err"); const m = e?.message || String(e); if (el) el.textContent = m; else alert(m); };
async function run(fn) { try { await fn(); } catch (e) { fail(e); } }
const must = r => { if (r.error) throw r.error; return r.data; };
const signed = async (bucket, path) => (await sb.storage.from(bucket).createSignedUrl(path, 300)).data?.signedUrl;
const jobMeta = j => `${esc(j.organisation)} · ${esc(j.location || "Location flexible")} · ${FORMATS[j.format]} · ${JOB_TYPES[j.job_type]}`;
const jobTags = j => [...j.subjects, ...j.phases].map(t => tag(t)).join(" ");

const portal = { cfg: null, ready: false, click: {}, submit: {} };
const sessionGone = e => /session.?missing|session_not_found|invalid.?jwt|refresh.?token/i.test(String(e && (e.message || e.code || e)));
async function backToSignIn() { try { await sb.auth.signOut(); } catch (_) {} viewSignIn("Your sign-in expired. Please sign in again."); }

async function loadMe() {
  const { data: { session } } = await sb.auth.getSession();
  me = null; isVerifier = false;
  if (!session) return null;
  me = must(await sb.from("profiles").select("*").eq("id", session.user.id).maybeSingle());
  if (me) isVerifier = !!must(await sb.from("verifiers").select("user_id").eq("user_id", me.id).maybeSingle());
  return session;
}

function drawNav() {
  document.getElementById("navAuth").innerHTML = portal.ready
    ? portal.cfg.nav.map(([l, h]) => `<a href="${h}">${esc(l)}</a>`).join("") + ` <button class="btn btn-outline btn-small" data-act="signout">Sign out</button>` : "";
}

function renderCurrent() {
  const path = location.hash.replace(/^#\/?/, "").split("/")[0];
  return (portal.cfg.routes[path] || portal.cfg.routes[""])();
}
const refresh = () => run(renderCurrent);

// Order of checks: signed in -> is staff for this portal -> second step done -> show the page.
async function route() {
  portal.ready = false; drawNav();
  await run(async () => { try {
    const session = await loadMe();
    if (!session) return viewSignIn();
    if (!portal.cfg.allowed()) { await sb.auth.signOut(); return viewSignIn(`This account is not set up for the ${portal.cfg.title}. You have been signed out.`); }
    const aal = must(await sb.auth.mfa.getAuthenticatorAssuranceLevel());
    if (aal.currentLevel !== "aal2") return aal.nextLevel === "aal2" ? viewMfaChallenge() : viewMfaEnroll();
    portal.ready = true; drawNav();
    await renderCurrent();
  } catch (e) { if (sessionGone(e)) return backToSignIn(); throw e; } });
}

function startPortal(cfg) {
  portal.cfg = cfg;
  window.addEventListener("hashchange", () => { if (portal.ready) refresh(); });
  route();
}

function viewSignIn(msg = "") {
  app.innerHTML = `<h1>${esc(portal.cfg.title)}</h1><p class="lede">Staff sign-in only.</p>${msg ? `<div class="notice">${esc(msg)}</div>` : ""}
  <form class="card" data-form="signin"><label>Email<input name="email" type="email" required autocomplete="email"></label>
  <label>Password<input name="password" type="password" required autocomplete="current-password"></label>
  <button class="btn btn-primary">Sign in</button> <button type="button" class="link-btn" data-act="forgot">Forgot your password?</button><p class="err" role="alert"></p></form>`;
}

async function viewMfaEnroll() {
  const f = must(await sb.auth.mfa.listFactors());
  for (const x of f.all || []) if (x.status === "unverified") { try { await sb.auth.mfa.unenroll({ factorId: x.id }); } catch (_) {} }
  const e = must(await sb.auth.mfa.enroll({ factorType: "totp", friendlyName: "SAPIORA staff " + Math.random().toString(36).slice(2, 7) }));
  app.innerHTML = `<h1>Set up two-step sign-in</h1><p class="lede">Staff accounts handle private documents and payments, so a second step is required. Scan this code with an authenticator app (Google Authenticator, Microsoft Authenticator, Authy or 1Password), then enter the 6-digit code it shows.</p>
  <div class="card"><img src="${esc(e.totp.qr_code)}" alt="QR code for your authenticator app" width="200" height="200">
  <p><small>Cannot scan? Type this key into the app instead: <b>${esc(e.totp.secret)}</b></small></p>
  <form data-form="mfacode" data-factor="${esc(e.id)}"><label>6-digit code<input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="one-time-code"></label>
  <button class="btn btn-primary">Turn on and continue</button> <button type="button" class="link-btn" data-act="signout">Cancel</button><p class="err" role="alert"></p></form></div>`;
}

async function viewMfaChallenge() {
  const factor = (must(await sb.auth.mfa.listFactors()).totp || [])[0];
  if (!factor) return viewMfaEnroll();
  app.innerHTML = `<h1>Two-step sign-in</h1><p class="lede">Enter the 6-digit code from your authenticator app.</p>
  <form class="card" data-form="mfacode" data-factor="${esc(factor.id)}"><label>6-digit code<input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" required autocomplete="one-time-code" autofocus></label>
  <button class="btn btn-primary">Verify</button> <button type="button" class="link-btn" data-act="signout">Cancel</button><p class="err" role="alert"></p></form>`;
}

const commonClick = {
  signout: async () => { await sb.auth.signOut(); await route(); },
  forgot: async b => {
    const f = b.closest("form"), el = f.querySelector(".err"), email = f.elements.email.value.trim();
    if (!email) { el.style.color = "#8a2f2f"; el.textContent = "Enter your email above first."; return; }
    must(await sb.auth.resetPasswordForEmail(email, { redirectTo: location.origin + "/reset.html" }));
    el.style.color = "#2f6a3d"; el.textContent = "If that email has an account, a reset link is on its way.";
  }
};
const commonSubmit = {
  signin: async (f, v) => { must(await sb.auth.signInWithPassword({ email: v.email, password: v.password })); await route(); },
  mfacode: async (f, v) => {
    const factorId = f.dataset.factor, code = String(v.code).trim();
    const { data: { session } } = await sb.auth.getSession();
    if (!session) return backToSignIn();
    const step = (name, r) => { if (r.error) { const e = new Error(name + ": " + r.error.message); e.code = r.error.code; throw e; } return r.data; };
    try {
      const ch = step("challenge", await sb.auth.mfa.challenge({ factorId }));
      step("verify", await sb.auth.mfa.verify({ factorId, challengeId: ch.id, code }));
    } catch (e) { if (sessionGone(e)) return backToSignIn(); throw e; }
    await route();
  }
};

document.addEventListener("click", e => {
  const b = e.target.closest("[data-act]"); if (!b) return;
  const h = commonClick[b.dataset.act] || portal.click[b.dataset.act];
  if (h) run(() => h(b, b.dataset.id));
});
document.addEventListener("submit", e => {
  const f = e.target, k = f.dataset.form; if (!k) return;
  e.preventDefault();
  const h = commonSubmit[k] || portal.submit[k];
  if (h) run(() => h(f, Object.fromEntries(new FormData(f))));
});
